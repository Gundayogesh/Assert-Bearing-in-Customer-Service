import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '../../../node_modules/@angular/common/http';
import { User } from './user';


@Injectable({
  providedIn: 'root'
})

  
export class LoginService {
  public postData;
    public httpOptions : any;
  
    constructor(private httpService: HttpClient) {
      this.httpOptions = {
      headers: new HttpHeaders( { 'Content-Type': 'application/json; charset=utf-8',
      'BrowserToken' : 'auth_Token'})
    }
  }
   
sendingUserObject(us1:User){
  return this.httpService.post('http://localhost:8765/resourceTrackerTool/LoginApi/getUser',us1,this.httpOptions);
}

}
