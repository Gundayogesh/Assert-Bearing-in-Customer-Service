export class User{
    userName:string;
    emailId:string;
    password:string;
    message:string;
}