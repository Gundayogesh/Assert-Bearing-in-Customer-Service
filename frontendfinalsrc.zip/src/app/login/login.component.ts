import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {FormBuilder,FormGroup,FormControl, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import { LoginService } from './login.service';
import { User } from './user';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private fb: FormBuilder,private router: Router,private service:LoginService) { }
   user:User;
   public postData;
    public loginForm:FormGroup;
   
    ngOnInit() {
      this.loginForm=this.fb.group({
        userName:['',[Validators.required]],
        emailId:['',[Validators.required]],
        password:['',[Validators.required]]
      });
    }
    loginSubmit() : void {
      this.service.sendingUserObject(this.loginForm.value).subscribe(data=>{
        this.postData=data;
        this.user = this.postData
        if(this.user.message=="successfull"){
          sessionStorage.setItem("user",this.user.userName);
          this.router.navigate(["home"]);
        }
        else{
          alert("Invalid credentials");
        }
      })
    }     
    openRegister()
    {
      this.router.navigate(["register"])

    }
}









  

