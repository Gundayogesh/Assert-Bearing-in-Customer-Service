import { TestBed } from '@angular/core/testing';

import { TimesheetlistService } from './timesheetlist.service';

describe('TimesheetlistService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TimesheetlistService = TestBed.get(TimesheetlistService);
    expect(service).toBeTruthy();
  });
});
