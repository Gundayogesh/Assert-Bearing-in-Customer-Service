import { Component, OnInit, ElementRef, ViewEncapsulation, ViewChild } from '@angular/core';
import { TimesheetlistService } from './timesheetlist.service';
import { timeSheet } from '../time-sheet/timesheet';
import { MatPaginator, MatSort, MatTableDataSource, MatSnackBar } from '@angular/material'
import { jqxGridComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxgrid'
import { jqxPanelComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxpanel';
import { HomeService } from '../home/home.service';
import { GraphObject } from '../home/home/graphObject'
import * as FileSaver from 'file-saver'
@Component({
  selector: 'app-time-sheet-list',
  templateUrl: './time-sheet-list.component.html',
  styleUrls: ['./time-sheet-list.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TimeSheetListComponent implements OnInit {
  displayedColumns: string[] = ['empNo', 'woname', 'month', 'noOfHours', 'billingAmount'];
  timeSheetData: any[];
  tableData: timeSheet[];
  totalAmount: number;
  fetchedReports: timeSheet[] = [];
  amountTillDate: number;
  editeddata: timeSheet[] = [];
  exceededAmount: boolean;
  nearToExceed: boolean;
  public postData;
  public projectData;
  amountData: GraphObject[];
  sampl: timeSheet;
  returnObj:timeSheet[];
  sampl1: timeSheet;
  searchKey: string;
  listData: MatTableDataSource<any>;
  @ViewChild('cellBeginEditLog') cellBeginEditLog: ElementRef;
  @ViewChild('cellEndEditLog') cellEndEditLog: ElementRef;
  @ViewChild('myGrid') myGrid: jqxGridComponent;
  @ViewChild('myPanel') myPanel: jqxPanelComponent;
  source: any;
  dataAdapter: any;
  columnName: any;
  rateValue: number = 0;
  changingValue: number;
  action: string="Close!";
  constructor(private snackBar: MatSnackBar,private service: TimesheetlistService, private homeService: HomeService) { }
  ngOnInit() {
    console.log(document.body.offsetHeight);
    this.source =
      {
        datatype: 'array',
        datafields:
          [
            { name: 'status', type: 'string' },
            { name: 'projectCode', type: 'string' },
            { name: 'infyManager', type: 'string' },
            { name: 'projectId', type: 'string' },
            { name: 'woName', type: 'string' },
            { name: 'visaManager', type: 'string' },
            { name: 'empNo', type: 'number' },
            { name: 'resourceName', type: 'string' },
            { name: 'unit', type: 'string' },
            { name: 'loc', type: 'string' },
            { name: 'role', type: 'string' },
            { name: 'jobTier', type: 'string' },
            { name: 'rate', type: 'number' },
            { name: 'oct', type: 'number' },
            { name: 'nov', type: 'number' },
            { name: 'dec', type: 'number' },
            { name: 'jan', type: 'number' },
            { name: 'feb', type: 'number' },
            { name: 'mar', type: 'number' },
            { name: 'apr', type: 'number' },
            { name: 'may', type: 'number' },
            { name: 'jun', type: 'number' },
            { name: 'jul', type: 'number' },
            { name: 'aug', type: 'number' },
            { name: 'sep', type: 'number' },
            { name: 'amountTillDate', type: 'number' },
            { name: 'message', type: 'string' }
          ]
      };
    this.service.getAllTimeSheet().subscribe(data => {
      this.timeSheetData = data;
      this.tableData = this.timeSheetData;
      this.source.localdata = this.tableData;
      this.dataAdapter = new jqx.dataAdapter(this.source);
    });
  }

  // getWidth(): any {
  //   if (document.body.offsetWidth < 850) {
  //     return '90%';
  //   }

  //   return 850;
  // }
  columns: any[] =
    [
      { text: 'Status', columntype: 'dropdownlist', datafield: 'status', width: 120,editable:false },
      { text: 'Project Code', columntype: 'dropdownlist', datafield: 'projectCode', width: 120 ,editable:false},
      { text: 'Infy Manager', columntype: 'textbox', datafield: 'infyManager', width: 120 ,editable:false},
      { text: 'Project Id', columntype: 'dropdownlist', datafield: 'projectId', width: 120 ,editable:false},
      { text: 'WO Name', columntype: 'dropdownlist', datafield: 'woName', width: 120 ,editable:false},
      { text: 'Visa Manager', columntype: 'textbox', datafield: 'visaManager', width: 120 ,editable:false},
      { text: 'Employee No', columntype: 'textbox', datafield: 'empNo', width: 120 ,editable:false},
      { text: 'Resource Name', columntype: 'textbox', datafield: 'resourceName', width: 120 ,editable:false},
      { text: 'Unit', columntype: 'textbox', datafield: 'unit', width: 120 ,editable:false},
      { text: 'Location', columntype: 'textbox', datafield: 'loc', width: 120 ,editable:false},
      { text: 'Role', columntype: 'textbox', datafield: 'role', width: 120 ,editable:false},
      { text: 'Job Tier', columntype: 'textbox', datafield: 'jobTier', width: 120 ,editable:false},
      { text: 'Rate', columntype: 'textbox', datafield: 'rate', width: 120 ,editable:false},
      { text: 'OCT', columntype: 'textbox', datafield: 'oct', width: 60 },
      { text: 'NOV', columntype: 'textbox', datafield: 'nov', width: 60 },
      { text: 'DEC', columntype: 'textbox', datafield: 'dec', width: 60 },
      { text: 'JAN', columntype: 'textbox', datafield: 'jan', width: 60 },
      { text: 'FEB', columntype: 'textbox', datafield: 'feb', width: 60 },
      { text: 'MAR', columntype: 'textbox', datafield: 'mar', width: 60 },
      { text: 'APR', columntype: 'textbox', datafield: 'apr', width: 60 },
      { text: 'MAY', columntype: 'textbox', datafield: 'may', width: 60 },
      { text: 'JUN', columntype: 'textbox', datafield: 'jun', width: 60 },
      { text: 'JUL', columntype: 'textbox', datafield: 'jul', width: 60 },
      { text: 'AUG', columntype: 'textbox', datafield: 'aug', width: 60 },
      { text: 'SEP', columntype: 'textbox', datafield: 'sep', width: 60 },
      { text: 'Amount Till Date', columntype: 'textbox', datafield: 'amountTillDate', width: 120,editable:false },

    ];


  rowValues: string = '';
  // myGridOnCellBeginEdit(event: any): void {
  //   console.log("myGridOnCellBeginEdit::::",event)
  //     let args = event.args;

  // };

  Cellclick(event: any): void {
    // Do Something
    // console.log("Cellclick::::::",event)
    this.columnName = event.args.datafield;

  }

  test(event: any): void 
  {
    console.log("Tabclick Value:::::::::;",event);
  }

  myGridOnCellEndEdit(event: any, name: any): void {
    console.log("changing Value:::::::::;",event);

    if (this.columnName == event.args.datafield) {
     
  
      // console.log("changing Value:::::::::;",event);
      let rate = event.args.row.rate;
      let newval= (event.args.value - event.args.oldvalue)*rate;
      this.amountTillDate+=newval;
      this.exceededAmount = false;
          this.nearToExceed = false;

          if (this.amountTillDate >= this.totalAmount) {
            this.exceededAmount = true;
            this.nearToExceed = false;
          }

          else if (this.amountTillDate >= this.totalAmount - 1000) {
            this.nearToExceed = true;
            this.exceededAmount = false;
          }

      this.sampl = event.args.row;
      // this.service.updateTimeSheet(this.sampl)
      this.editeddata.push(this.sampl);
      console.log("response::::", this.postData)
    }

    // console.log("name::::::",name)
    //   let args = event.args.row;


    // // if(this.rowValues==""){
    //   console.log("args:::",args);
    // this.editeddata.push(this.sampl);
    // //   console.log(this.sampl);
    // //    this.sampl1 = this.sampl;
    //   this.service.updateTimeSheet(args).subscribe(data=>{
    //      this.postData = data
    //      console.log(this.postData)
    //    });

    // }
    // this.rowValues=event.args.row.projectId;


  };
  // Cellendedit(event: any) {


    

    
    
  //   // if (this.columnName == event.args.datafield) {
  //   //   console.log("value:::::::", event.args.value);
  //   //   this.amountTillDate-=(this.rateValue*event.args.value)
  //   // }
  //   // console.log("Cell begin:::::::", event);
  //   // if (this.columnName == event.args.datafield) {
  //   //   console.log("value:::::::", event.args.value);
  //   //   this.amountTillDate-=(this.rateValue*this.changingValue)
  //   // }
  // }

  Rowdoubleclick(event: any): void {
    // console.log(event.args.row.bounddata.woName);
    this.rateValue = event.args.row.bounddata.rate;
    this.homeService.getProject().subscribe(data => {
      this.projectData = data;
      this.amountData = this.projectData;
      // console.log(this.amountData);
      // console.log(this.amountData.length);

      for (var _i = 0; _i < this.amountData.length; _i++) {

        if (this.amountData[_i].woname == event.args.row.bounddata.woName) {

          // this.amountTillDate = this.amountData[_i].amountTilldate-(this.changingValue*this.rateValue);
          // console.log("Changing value::::", this.changingValue)
          // console.log("Rate Value:::", this.rateValue);
          // console.log(this.amountData[_i].amountTilldate);
          // console.log(this.changingValue * this.rateValue);
          this.amountTillDate = this.amountData[_i].amountTilldate
          this.totalAmount = this.amountData[_i].totalAmount;
          this.exceededAmount = false;
          this.nearToExceed = false;

          if (this.amountTillDate >= this.totalAmount) {
            this.exceededAmount = true;
            this.nearToExceed = false;
          }

          else if (this.amountTillDate >= this.totalAmount - 100) {
            this.nearToExceed = true;
            this.exceededAmount = false;
          }
        }
      }
    });


  }









  // Rowselect(event: any): void 
  // {
  //     // console.log(event);
  //     this.rowValues="";
  //     this.sampl = event.args.row;
  // }


  allProjects() {
    this.homeService.getProject().subscribe(data => {
      this.projectData = data;
      this.amountData = this.projectData;
      console.log(this.amountData);
    });
  }







  getHeight(): any {
    if (document.body.offsetHeight < 520) {

      return document.body.offsetHeight * 0.7;
    }

    return 520;
  }





  myGridOnSort(event: any): void {
    this.myPanel.clearcontent();
    let sortinformation = event.args.sortinformation;
    let sortdirection = sortinformation.sortdirection.ascending ? 'ascending' : 'descending';
    if (!sortinformation.sortdirection.ascending && !sortinformation.sortdirection.descending) {
        sortdirection = 'null';
    }
    let eventData = 'Triggered "sort" event <div>Column:' + sortinformation.sortcolumn + ', Direction: ' + sortdirection + '</div>';
    this.myPanel.prepend('<div style="margin-top: 5px;">' + eventData + '</div>');
};





  upLoadData() {
    
    this.service.updateTimeSheet(this.editeddata).subscribe(data => {
      this.postData = data
      this.returnObj = this.postData
      // console.log("return Obj",this.returnObj[0].message);
       this.snackBar.open(this.returnObj[0].message, this.action, {
         duration: 3000,
       });
    });
    this.editeddata = [];
  }


  downloadExcel() {
    this.fetchedReports = this.tableData;

    var dataArray: Array<string> = [];
    let index: number = 0;
    dataArray.push("")
    dataArray.push("status")
    dataArray.push("projectCode")
    dataArray.push("infyManager")
    dataArray.push("projectId")
    dataArray.push("woName")
    dataArray.push("visaManager")
    dataArray.push("empNo")
    dataArray.push("resourceName")
    dataArray.push("unit")
    dataArray.push("loc")
    dataArray.push("role")
    dataArray.push("jobTier")
    dataArray.push("rate")
    dataArray.push("oct")
    dataArray.push("nov")
    dataArray.push("dec")
    dataArray.push("jan")
    dataArray.push("feb")
    dataArray.push("mar")
    dataArray.push("apr")
    dataArray.push("may")
    dataArray.push("jun")
    dataArray.push("jul")
    dataArray.push("aug")
    dataArray.push("sep")
    dataArray.push("amountTillDate")
    dataArray.push("Oct cost")
    dataArray.push("Nov Cost")
    dataArray.push("Dec Cost")
    dataArray.push("Jan Cost")
    dataArray.push("Feb Cost")
    dataArray.push("Mar Cost")
    dataArray.push("Apr Cost")
    dataArray.push("May Cost")
    dataArray.push("Jun Cost")
    dataArray.push("Jul Cost")
    dataArray.push("Aug Cost")
    dataArray.push("Sep Cost"+"\n")

    for (let report of this.fetchedReports) {

      dataArray.push(report.status as string)
      dataArray.push(report.projectCode as string)
      dataArray.push(report.infyManager as string)
      dataArray.push(report.projectId as string)
      dataArray.push(report.woName as string)
      dataArray.push(report.visaManager as string)
      dataArray.push(report.empNo.toString() as string)
      dataArray.push(report.resourceName as string)
      dataArray.push(report.unit as string)
      dataArray.push(report.loc as string)
      dataArray.push(report.role as string)
      dataArray.push(report.jobTier as string)
      dataArray.push(report.rate.toString() as string)
      dataArray.push(report.oct.toString() as string)
      dataArray.push(report.nov.toString() as string)
      dataArray.push(report.dec.toString() as string)
      dataArray.push(report.jan.toString() as string)
      dataArray.push(report.feb.toString() as string)
      dataArray.push(report.mar.toString() as string)
      dataArray.push(report.apr.toString() as string)
      dataArray.push(report.may.toString() as string)
      dataArray.push(report.jun.toString() as string)
      dataArray.push(report.jul.toString() as string)
      dataArray.push(report.aug.toString() as string)
      dataArray.push(report.sep.toString() as string)
      dataArray.push(report.amountTillDate.toString() as string )
      dataArray.push((report.rate*report.oct ).toString() as string)
      dataArray.push((report.rate*report.nov ).toString() as string)
      dataArray.push((report.rate*report.dec ).toString() as string)
      dataArray.push((report.rate*report.jan ).toString() as string)
      dataArray.push((report.rate*report.feb ).toString() as string)
      dataArray.push((report.rate*report.mar ).toString() as string)
      dataArray.push((report.rate*report.apr ).toString() as string)
      dataArray.push((report.rate*report.may ).toString() as string)
      dataArray.push((report.rate*report.jun ).toString() as string)
      dataArray.push((report.rate*report.jul ).toString() as string)
      dataArray.push((report.rate*report.aug ).toString() as string)
      dataArray.push((report.rate*report.sep ).toString() as string+"\n")

    }
  
    var data: Blob = new Blob([[dataArray]], {
      type: "string[[]]"
    });
    FileSaver.saveAs(data, "Time_Sheet_" + '_export_' + ".csv");

  }
}