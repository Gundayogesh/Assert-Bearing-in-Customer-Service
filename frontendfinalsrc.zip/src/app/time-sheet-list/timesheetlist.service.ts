import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError, map } from 'rxjs/operators';
import { timeSheet } from '../time-sheet/timesheet';

@Injectable({
  providedIn: 'root'
})
export class TimesheetlistService {
  public postData;
  public httpOptions: any;
  dataUrl = "http://localhost:8765/resourceTrackerTool/costApi/getAllCostEntity";
  url: any;
  timeSheetVal:timeSheet;
  constructor(private httpService: HttpClient) {
  this.httpOptions = {
    headers: new HttpHeaders(
      {
        'Content-Type': 'application/json; charset=utf-8',
        'BrowserToken': 'auth_Token'
      })
  }
  }
  getAllTimeSheet() {

    return this.httpService.get<any[]>(this.dataUrl).pipe(map(data => data));
  }
  updateTimeSheet(data:any[])
  {
    console.log("db service",data);
    //  this.timeSheetVal = timeSheetList
    //  console.log(this.timeSheetVal);
    return this.httpService.post('http://localhost:8765/resourceTrackerTool/costApi/updateCostEntity',data,this.httpOptions);
  }
}
