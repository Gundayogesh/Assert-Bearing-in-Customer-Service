import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '../../../node_modules/@angular/common/http';
import { User } from '../login/user';
@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  public postData;
  public httpOptions : any;
  constructor(private httpService: HttpClient) {
    this.httpOptions = {
    headers: new HttpHeaders( { 'Content-Type': 'application/json; charset=utf-8',
    'BrowserToken' : 'auth_Token'})
  }
}
registerNewUser(user:User)
{
  return this.httpService.post('http://localhost:8765/resourceTrackerTool/LoginApi/adduser',user,this.httpOptions);
}
}
