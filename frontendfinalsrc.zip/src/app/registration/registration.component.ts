import { Component, OnInit } from '@angular/core';
import {MatDialog, MatSnackBar} from '@angular/material';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {FormBuilder,FormGroup,FormControl, Validators} from '@angular/forms';
import { RegistrationService } from './registration.service';
import { User } from '../login/user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  user:User;
  public postData;
  action:string="Close!"
  constructor(private snackBar: MatSnackBar,private fb: FormBuilder,private service:RegistrationService) { }
   
  public registrationForm:FormGroup;
  ngOnInit() {
    this.registrationForm=this.fb.group({
      userName:[,[Validators.required]],
      email:[,[Validators.required,Validators.email]],
      password:[,[Validators.required]]
    });
  }
  registerNewUser(){
   this.service.registerNewUser(this.registrationForm.value).subscribe(data => {
    this.postData = data;
    console.log(this.postData);
    this.user=this.postData;
    this.snackBar.open(this.user.message, this.action, {
      duration: 3000,
    });
    }
      )};
}