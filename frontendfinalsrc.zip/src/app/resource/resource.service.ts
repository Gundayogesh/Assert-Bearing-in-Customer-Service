import { Injectable } from '@angular/core'; 
import { FormGroup ,FormControl, Validators} from '@angular/forms';
import { resourceDetails } from './resource/resourceDetails';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { resource } from 'selenium-webdriver/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError, map } from 'rxjs/operators';
import { timeSheet } from '../time-sheet/timesheet';
@Injectable({
  providedIn: 'root'
})
export class ResourceService {
  resourceList: resourceDetails[] ;
  public postData;
  public httpOptions : any;

  dataUrl="http://localhost:8765/resourceTrackerTool/ResourceMasterApi/getAllResources";
  constructor(private httpService: HttpClient) {this.httpOptions = {
    headers: new HttpHeaders(
      { 'Content-Type': 'application/json; charset=utf-8',
        'BrowserToken' : 'auth_Token'})
  }
} 

  getResource():Observable<any>{

    return this.httpService.get<any[]>(this.dataUrl).pipe(map(data=>data));

  }
  addResource(resource:resourceDetails){
    return this.httpService.post('http://localhost:8765/resourceTrackerTool/ResourceMasterApi/addResourceMaster',resource,this.httpOptions);
  } 
  editResource(resource:resourceDetails){
    return this.httpService.post('http://localhost:8765/resourceTrackerTool/ResourceMasterApi/updateResourceMaster/'+resource.empNo,resource,this.httpOptions);

  }
  
  deleteResource(resource:resourceDetails) {
    return this.httpService.post('http://localhost:8765/resourceTrackerTool/ResourceMasterApi/deleteResourceMaster',resource,this.httpOptions).subscribe(data => {
      this.postData = data;
  });
  }
  resourceListByManager(visaManager:string)
  {
    return this.httpService.post('http://localhost:8765/resourceTrackerTool/ResourceMasterApi/getResourceByProjectCode/'+visaManager,this.httpOptions);
  }
  addingCostForResource(timeSheet:timeSheet)
  {
    return this.httpService.post('http://localhost:8765/resourceTrackerTool/costApi/addCost',timeSheet,this.httpOptions)
  }
 
}