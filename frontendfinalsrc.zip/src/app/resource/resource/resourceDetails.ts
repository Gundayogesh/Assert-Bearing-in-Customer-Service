export class resourceDetails
{
		empNo:number;
		visaNumber:number;
		resourceName:string;
		unit:string;
		LOC:string;
		city:string;
		jobTier:string;
		primarySkill:string;
		secondarySkill:string;
		role:string;
		rate:number;
		visaManager:string;
		infyManager:string;
		projectCode:string;
		message:string;
}