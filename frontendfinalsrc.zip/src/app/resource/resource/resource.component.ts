import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ResourceService } from '../resource.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material';
import { resourceDetails } from './resourceDetails';

@Component({
  selector: 'app-resource',
  templateUrl: './resource.component.html',
  styleUrls: ['./resource.component.css']
})
export class ResourceComponent implements OnInit {

  constructor(private fb: FormBuilder, private dialogRef: MatDialogRef<ResourceComponent>, private service: ResourceService, @Inject(MAT_DIALOG_DATA) public data: any, private snackBar: MatSnackBar) { }
  public resourceForm: FormGroup;
  public postData;
  action: string = "Close!"
  resourceDetails: resourceDetails;
  returnval: number;
  message: string;
  onNoClick(): void {
    this.dialogRef.close();
  }
  ngOnInit() {
    this.resourceForm = this.fb.group({
      empNo: [this.data.empNo, [Validators.required]],
      visaNumber: [this.data.visaNumber, [Validators.required]],
      jobTier: [this.data.jobTier, [Validators.required]],
      role: [this.data.role, [Validators.required]],
      rate: [this.data.rate, [Validators.required]],
      resourceName: [this.data.resourceName, [Validators.required]],
      unit: [this.data.unit, [Validators.required]],
      loc: [this.data.loc, [Validators.required]],
      city: [this.data.city, [Validators.required]],
      primarySkill: [this.data.primarySkill, [Validators.required]],
      secondarySkill: [this.data.secondarySkill, [Validators.required]],
      visaManager: [this.data.visaManager, [Validators.required]],
      infyManager: [this.data.infyManager, [Validators.required]],
      projectCode: [this.data.projectCode, [Validators.required]],
      message: [this.data.message, [Validators.required]]
    })
  }
  save() {
    this.service.addResource(this.resourceForm.value).subscribe(data => {
      this.postData = data;
      this.resourceDetails = this.postData;
      this.dialogRef.close();
    });
    this.snackBar.open(this.resourceDetails.message, this.action, {
      duration: 3000,
    });
  }
}

