import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, Sort, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ResourceService } from '../resource.service';
import { ResourceComponent } from '../resource/resource.component';
import {EditResourceComponent} from '../edit-resource/edit-resource.component';
import { resourceDetails } from '../resource/resourceDetails';
import { ChecklistModule } from 'angular-checklist'
import {FormControl} from '@angular/forms'
import { Router } from '@angular/router';
@Component({
  selector: 'app-resource-list',
  templateUrl: './resource-list.component.html',
  styleUrls: ['./resource-list.component.css']
})
export class ResourceListComponent implements OnInit {
  toppings = new FormControl();
  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];
  isPopupOpened=false;
  editFlag:number=0; 
  searchKey1: string;
  errorMessage:string;
  resourceData:any[];
  resource1:any;
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['empNo', 'visaNumber', 'resourceName','projectCode','role','rate','jobTier', 'unit', 'loc', 'city','primarySkill','secondarySkill','visaManager','infyManager','actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private router: Router,private dialog?:MatDialog,private service?:ResourceService) { 

    
  }

  sortedData:resourceDetails[];
  ngOnInit() {
    if(sessionStorage.getItem("user")==null)
      {
          this.router.navigate(["login"])
      }
  this.service.getResource()
  .subscribe(data => {
      this.resourceData = data;  
      console.log(this.resourceData)
    this.listData = new MatTableDataSource(this.resourceData);
    this.listData.sort = this.sort;
    this.listData.paginator = this.paginator;
    console.log(this.listData);
});

   
  


  }
  // edit(resource:resourceDetails)
  // {
    
  // }
  get resourcesList(){
    return this.service.getResource();
  }
  
  add(){
    this.isPopupOpened=true
    const dialogRef=this.dialog.open(ResourceComponent,{
      width: '650px',
      height:'600px',
      data:{}
    }
      )
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    })

    
  }
  editResource(resource:resourceDetails) {
    this.isPopupOpened = true
    this.editFlag=1;
    const dialogRef = this.dialog.open(EditResourceComponent, {
      width: '650px',
      height:'600px',
      data: resource
    })
    
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
      this.editFlag=0;
    })
    
  }
  deleteResource(resource:resourceDetails) {
    
    this.service.deleteResource(resource);

  }
  onSearchClear1() {
    this.searchKey1 = "";
    this.applyFilter1();
  }
  applyFilter1() {
    this.listData.filter = this.searchKey1.trim().toLowerCase();
  }
  
}
function compare(a: number | string, b: number | string, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}