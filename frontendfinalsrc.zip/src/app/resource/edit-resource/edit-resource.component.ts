import { Component, OnInit,Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA, MatSnackBar} from '@angular/material';
import { ResourceService } from '../resource.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { resourceDetails } from '../resource/resourceDetails';
@Component({
  selector: 'app-edit-resource',
  templateUrl: './edit-resource.component.html',
  styleUrls: ['./edit-resource.component.css']
})
export class EditResourceComponent implements OnInit {
  public postData;
  action: string = "Close!"
  resourceDetails: resourceDetails;
  constructor(private snackBar: MatSnackBar,private fb: FormBuilder, private dialogRef: MatDialogRef<EditResourceComponent>,private service: ResourceService,@Inject(MAT_DIALOG_DATA) public data:any) { }
  public resourceForm:FormGroup;

  onNoClick():void{
    this.dialogRef.close();
  }

  ngOnInit() {
    this.resourceForm=this.fb.group({
     empNo: [this.data.empNo,[Validators.required]],
     visaNumber: [this.data.visaNumber, [Validators.required]],
     jobTier:[this.data.jobTier, [Validators.required]],
     role:[this.data.role, [Validators.required]],
     rate:[this.data.rate, [Validators.required]],
     resourceName: [this.data.resourceName, [Validators.required]],
     unit: [this.data.unit, [Validators.required]],
      loc: [this.data.loc, [Validators.required]],
      city: [this.data.city, [Validators.required]],
      primarySkill: [this.data.primarySkill, [Validators.required]],
      secondarySkill:[this.data.secondarySkill,[Validators.required]],
      visaManager:[this.data.visaManager,[Validators.required]],
      infyManager:[this.data.infyManager,[Validators.required]],
      projectCode:[this.data.projectCode,[Validators.required]],
      message:[this.data.message,[Validators.required]]
      })
   }
   save(){
       this.service.editResource(this.resourceForm.value).subscribe(data => {
         console.log("editResource:::::",data)
         if(data){
            this.postData = data;
            this.resourceDetails = this.postData;
            this.dialogRef.close();
            this.snackBar.open(this.resourceDetails.message, this.action, {
              duration: 3000,
            });
          }
    });
    
   }
}
