import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class HomeService {
  public postData;
  public httpOptions : any;
  dataUrl="http://localhost:8765/resourceTrackerTool/costApi/getAllgraphdetails";
  constructor(private httpService: HttpClient) { 
    headers: new HttpHeaders(
      { 'Content-Type': 'application/json; charset=utf-8',
        'BrowserToken' : 'auth_Token'})
  }
  getProject():Observable<any>{
    return this.httpService.get<any[]>(this.dataUrl).pipe(map(data=>data));

  }
}
