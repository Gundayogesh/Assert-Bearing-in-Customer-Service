import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { jqxChartComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxchart';
import { HomeService } from '../home.service';
import { projectDetails } from '../../project/project/projectDetails';
import { GraphObject } from './graphObject';

// import {xyz} from '../../../../assets/'
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    public projectData;
    sampleData:any[];
    projectList:projectDetails[];
    graphProjectData:GraphObject[];
    fetchedReports:GraphObject[];
    totalAmount:number=0;
  constructor(private router: Router,private service:HomeService) { }

  ngOnInit() {
      if(sessionStorage.getItem("user")==null)
      {
          this.router.navigate(["login"])
      }
      this.service.getProject()
      .subscribe(data => {
        this.projectData = data;
        this.projectList = this.projectData;
        console.log(this.projectList)
        this.sampleData=this.projectList; 
    });
  }
  donutClick(event: any): void 
    {
    //   console.log(event.args.elementValue);
    //   console.log(event.args.elementIndex);
      console.log(event);
    }
  source: any =
    {
        datatype: 'csv',
        datafields: [
            { name: 'Browser' },
            { name: 'Share' }
        ],
        // url: '../sampledata/desktop_browsers_share_dec2011.txt'
        url:'../../../../assets/desktop_browsers_share_dec2011.txt'
 };
    dataAdapter: any = new jqx.dataAdapter(this.source, { async: false, autoBind: true, loadError: (xhr: any, status: any, error: any) => { alert('Error loading "' + this.source.url + '" : ' + error); } });
    legendPosition: any = { left: 520, top: 140, width: 100, height: 100 };
    donutPadding: any = { left: 5, top: 5, right: 5, bottom: 5 };
    donutTitlePadding: any = { left: 0, top: 0, right: 0, bottom: 10 };
	
	
    donutSeriesGroups: any[] =
    [
        {
            type: 'donut',
            showLabels: true,
            series:
            [
                {
                    dataField: 'Share',
                    displayText: 'Browser',
                    labelRadius: 120,
                    initialAngle: 15,
                    radius: 170,
                    innerRadius: 70,
                    centerOffset: 0,
                    formatSettings: { sufix: '%', decimalPlaces: 1 }
                }
            ]
        }
    ];
  
   

padding: any = { left: 5, top: 5, right: 5, bottom: 5 };
titlePadding: any = { left: 90, top: 0, right: 0, bottom: 10 };
xAxis: any =
{
    dataField: 'woname',
    showGridLines: true
};
seriesGroups: any[] =
[
    {
        type: 'column',
        columnsGapPercent: 50,
        seriesGapPercent: 0,
        valueAxis:
        {
            unitInterval: 8000,
            minValue: 0,
            maxValue: 100000,
            displayValueAxis: true,
            description: 'Amount in $',
            axisSize: 'auto',
            tickMarksColor: '#888888'
        },
        series: [
            { dataField: 'totalAmount', displayText: 'Total Amount' },
         { dataField: 'amountTilldate', displayText: 'Amount Till Date' },
            
        ]
    }
];
}
