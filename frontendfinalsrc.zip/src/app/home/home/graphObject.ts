export class GraphObject{
    woname:string;
    totalAmount:number;
    amountTilldate:number;
}