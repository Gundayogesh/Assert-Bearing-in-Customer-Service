import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home/home.component';
import { ResourceListComponent } from './resource/resource-list/resource-list.component';
import { ProjectListComponent } from './project/project-list/project-list.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { UploadExcelComponent } from './upload-excel/upload-excel.component';
import { TimeSheetComponent } from './time-sheet/time-sheet.component';
import { LoginComponent } from './login/login.component';
import { AppComponent } from './app.component';
import { TimeSheetListComponent } from './time-sheet-list/time-sheet-list.component';
import { RegistrationComponent } from './registration/registration.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: 'home', component: HomeComponent
  },
  {
    path: 'register', component: RegistrationComponent
  },
  {
    path: 'project', component: ProjectListComponent,
  },
  {
    path: 'resource', component: ResourceListComponent,
  },
  {
    path: 'uploadExcel', component: UploadExcelComponent,
  },
  {
    path: 'timeSheet', component: TimeSheetComponent,
  },
  {
    path: 'timeSheetList', component: TimeSheetListComponent
  },
  {
    path: 'login', component: LoginComponent,
  },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})


export class AppRoutingModule { }
