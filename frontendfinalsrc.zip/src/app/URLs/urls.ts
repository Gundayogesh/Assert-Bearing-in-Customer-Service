export class urls{
    
}