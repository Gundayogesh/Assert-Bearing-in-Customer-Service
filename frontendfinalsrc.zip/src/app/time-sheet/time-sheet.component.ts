import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../project/project.service'
import {FormControl,FormGroup, Validators, FormBuilder} from '@angular/forms';
import { projectDetails } from '../project/project/projectDetails';
import { ResourceService } from '../resource/resource.service';
import { timeSheet } from './timesheet';
import {delay} from 'rxjs/operators'
import { resourceDetails } from '../resource/resource/resourceDetails';
import { Router } from '@angular/router';
import { MatSnackBar, MatDialogRef } from '@angular/material'
@Component({
  selector: 'app-time-sheet',
  templateUrl: './time-sheet.component.html',
  styleUrls: ['./time-sheet.component.css']
})
export class TimeSheetComponent implements OnInit {
  selectedProject:string;
  selectedResource:number;
  month:string;
  hours:number;
  lengthOfResourceList=false;
  timeSheetValue : timeSheet
  action:string="Close!"
  public postData;
  monthsList:string[]=['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  resourceList:resourceDetails[];
  projectList:any[];
  timeSheetForm: FormGroup
  constructor(private snackBar: MatSnackBar,private dialogRef: MatDialogRef<TimeSheetComponent>,private router: Router,private fb: FormBuilder, private projectService?: ProjectService, private resourceService?: ResourceService) { }
  onNoClick():void{
    this.dialogRef.close();
  }
  ngOnInit() {
    if(sessionStorage.getItem("user")==null)
      {
          this.router.navigate(["login"])
      }
    this.projectService.getProject().subscribe(data => {
      this.projectList = data; 
      console.log(this.projectList);
      });

      this.timeSheetForm=this.fb.group({
        woname: ['',[Validators.required]],
        empNo: ['',[Validators.required]],
        month: ['',[Validators.required]],
        noOfHours: ['',[Validators.required]],
      });
    }
    
    
  onChangeProject(e)
  {

    if(!e)
    {
      console.log(this.selectedProject)
      this.resourceService.resourceListByManager(this.selectedProject).subscribe(data => {
        this.postData = data;
      this.resourceList = this.postData;
      if(this.resourceList.length==0)
      {
        this.lengthOfResourceList = true;

      }
      console.log(this.resourceList.length);})
    }
  }
  // onChangeResource(e)
  // {
  //   if(!e)
  //   {
  //     // console.log(this.timeSheetValue.month);
  //   }
  // }
  save()
  {
    this.resourceService.addingCostForResource(this.timeSheetForm.value).subscribe(data => {
      this.postData = data;
      this.timeSheetValue = this.postData;
      // this.snackBar.open(this.timeSheetValue.message, this.action, {
      //   duration: 3000,
      // });
      this.dialogRef.close();
  });
    
  }
}