import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import { ChartModule } from '../../modules/chart.module'
// import { ChartModule } from '../../'
// import { jqxChartComponent } from 'jqwidgets-framework/jqwidgets-ts/angular_jqxchart';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home/home.component';
import { ResourceComponent } from './resource/resource/resource.component';
import { ProjectComponent } from './project/project/project.component';
import { HttpClientModule } from '@angular/common/http'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
// import { ResourceDetailsComponent } from './resource/resource-details/resource-details.component';
import { ResourceService } from './resource/resource.service';
import { ProjectService } from './project/project.service';
import { ResourceListComponent } from './resource/resource-list/resource-list.component';
import { ProjectListComponent } from './project/project-list/project-list.component';
import { MaterialModule } from './material/material.module';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EditResourceComponent } from './resource/edit-resource/edit-resource.component';
import { EditProjectComponent } from './project/edit-project/edit-project.component';
import { ChecklistModule } from 'angular-checklist';
import { MatFileUploadModule } from 'angular-material-fileupload'
import { UploadExcelComponent } from './upload-excel/upload-excel.component';
import { TimeSheetComponent } from './time-sheet/time-sheet.component'
import { CommonModule } from '@angular/common';
import { jqxChartComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxchart';
import { jqxGridComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxgrid';
import { jqxCheckBoxComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxcheckbox';
import { jqxPanelComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxpanel';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { TimeSheetListComponent } from './time-sheet-list/time-sheet-list.component';
import { LoginService } from './login/login.service';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ResourceComponent,
    ProjectComponent,
    // ResourceDetailsComponent,
    ResourceListComponent,
    ProjectListComponent,
    PageNotFoundComponent,
    EditResourceComponent,
    EditProjectComponent,
    UploadExcelComponent,
    TimeSheetComponent,
    jqxChartComponent,
    jqxGridComponent,
    jqxCheckBoxComponent,
    jqxPanelComponent,
    LoginComponent,
    // jqxFileUploadComponent,
    RegistrationComponent,
    TimeSheetListComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MaterialModule,
    ChecklistModule,
    MatFileUploadModule,
    CommonModule
  ],
  providers: [ResourceService, ProjectService],
  entryComponents: [ResourceComponent, ProjectComponent, EditResourceComponent, EditProjectComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
