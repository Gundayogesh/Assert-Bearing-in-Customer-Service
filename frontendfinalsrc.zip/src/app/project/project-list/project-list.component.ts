import { Component, OnInit, ViewChild } from '@angular/core';
import { ProjectService } from '../project.service';
import { MatPaginator, MatDialog, MatTableDataSource, MatSort, MatDialogConfig } from '@angular/material';
import { ProjectComponent } from '../project/project.component';
import { projectDetails } from '../project/projectDetails';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';
import { EditProjectComponent } from '../edit-project/edit-project.component';
import {Router} from '@angular/router';

@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.css']
})
export class ProjectListComponent implements OnInit {
  isPopupOpened = false
  displayedColumns: string[] = ['projectId', 'cw', 'woname', 'rtn', 'visaManager', 'visaDM', 'functionalHead', 'svp', 'costcenter', 'amount', 'costType', 'projectType', 'startDate', 'endDate', 'dateSubmitted', 'wostatus', 'clientServiceManager', 'portfolio', 'oppID', 'woversion', 'projectCode', 'actions'];
  sortedData: projectDetails[];
  listData: MatTableDataSource<any>;
  sample:projectDetails[];
  public columnForm: FormGroup;

  // toppings = new FormControl();
  
  toppingList = [
    {
      id:0,
    name: 'Extra cheese'
    },
    {
      id:1,
      name: 'cheese'
      }
  ];

  projectData: any[];
  project1: any;
  searchKey: string;
  constructor(private router: Router,private dialog?: MatDialog, private service?: ProjectService) {
    // this.sortedData = this.projectList.slice();
  }
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;


  toggleSegments(e, list) {
    console.log("event triggred::", e)
    console.log("event list::", list)
  }

  ngOnInit() {
    if(sessionStorage.getItem("user")==null)
      {
          this.router.navigate(["login"])
      }
    
    this.service.getProject();

    this.service.getProject()
      .subscribe(data => {
        this.projectData = data;
        this.listData = new MatTableDataSource(this.projectData);
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
      //   for(let project of this.sample) { 
      //     console.log(project.woname)
      // }
      });
  }
  get projectList() {
    return this.service.getProject()
  }

  add() {
    this.isPopupOpened = true
    const dialogRef = this.dialog.open(ProjectComponent, {
      width: '800px',
      height:'650px',
      data: {}
    })
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    })
    // this.listData = new MatTableDataSource(this.projectList.slice());

  }
  deleteProject(project: projectDetails) {
    this.service.deleteProject(project);
    this.service.getProject()
      .subscribe(data => {
        this.projectData = data;

        this.listData = new MatTableDataSource(this.projectData);
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;

      });

  }
  editProject(project: projectDetails) {
    this.isPopupOpened = true
    // const project=this.service.getProject().find(c=>c.projectCode===projectCode)
    const dialogRef = this.dialog.open(EditProjectComponent, {
      width: '800px',
      height:'650px',
      data: project
    })
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    })
    this.service.getProject().subscribe(data => {
      this.projectData = data;

      this.listData = new MatTableDataSource(this.projectData);
      this.listData.sort = this.sort;
      this.listData.paginator = this.paginator;
    });
  }
  onSearchClear() {
    this.searchKey = "";
    this.applyFilter();
  }
  applyFilter() {
    this.listData.filter = this.searchKey.trim().toLowerCase();
  }
}
function compare(a: number | string, b: number | string, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}