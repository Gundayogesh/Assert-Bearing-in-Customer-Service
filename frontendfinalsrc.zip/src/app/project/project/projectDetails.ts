export class projectDetails
{
		projectId:string;
		cw: number;
		woname: string;
		rtn: string;
		visaManager: string; 
		visaDM: string;
		functionalHead:string; 
		svp: string;
		costcenter: number;
		amount: number;
		costType: string;
		projectType: string;
		startDate: Date;
		endDate: string;
		dateSubmitted:string; 
		wostatus: string;
		clientServiceManager:string; 
		portfolio: string;
		oppID: number;
		woversion: number;
		projectCode: string;
		message: string;
}