import { Inject,Component, OnInit } from '@angular/core';
import { projectDetails } from './projectDetails';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { FormGroup, FormBuilder, Validators,FormControl } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { ProjectService } from '../project.service';
@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {
  public projectForm: FormGroup;
  action:string="Close!"
  public postData;
  projectDetails:projectDetails
  constructor(private snackBar: MatSnackBar,private fb: FormBuilder, private dialogRef: MatDialogRef<ProjectComponent>, private service: ProjectService, @Inject(MAT_DIALOG_DATA) public data: any) { }
  onNoClick(): void {
    this.dialogRef.close();
  }
  ngOnInit() {
    this.projectForm = this.fb.group({
      projectId: [this.data.projectId, [Validators.required]],
      cw:  [this.data.cw, [Validators.required]],
      woname:  [this.data.woname, [Validators.required]],
      rtn:  [this.data.rtn, [Validators.required]],
      visaManager:  [this.data.visaManager, [Validators.required]],
      visaDM:  [this.data.visaDM, [Validators.required]],
      functionalHead:  [this.data.functionalHead, [Validators.required]],
      svp:  [this.data.svp, [Validators.required]],
      costcenter:  [this.data.costcenter, [Validators.required]],
      amount:  [this.data.amount, [Validators.required]],
      costType:  [this.data.costType, [Validators.required]],
      projectType:  [this.data.projectType, [Validators.required]],
      startDate:  [this.data.startDate, [Validators.required]],
      endDate:  [this.data.endDate, [Validators.required]],
      dateSubmitted:  [this.data.dateSubmitted, [Validators.required]],
      wostatus:  [this.data.wostatus, [Validators.required]],
      clientServiceManager:  [this.data.clientServiceManager, [Validators.required]],
      portfolio:  [this.data.portfolio, [Validators.required]],
      oppID:  [this.data.oppID, [Validators.required]],
      woversion:  [this.data.woversion, [Validators.required]],
      projectCode:  [this.data.projectCode, [Validators.required]]
    })
  }
  save() {
      this.service.addProject(this.projectForm.value).subscribe(data => {
        this.postData = data;
        this.projectDetails = this.postData
      this.snackBar.open(this.projectDetails.message, this.action, {
        duration: 3000,
      });
      this.dialogRef.close();
  });
  }
}
