import { Injectable } from '@angular/core';
import { projectDetails } from './project/projectDetails';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { retry, catchError, map } from 'rxjs/operators';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  
  projectList:projectDetails[]; 
  dataUrl="http://localhost:8765/resourceTrackerTool/ProjectMasterApi/getAllProjects";
  public postData;
  public httpOptions : any;
  constructor(private httpService: HttpClient) { 
    headers: new HttpHeaders(
      { 'Content-Type': 'application/json; charset=utf-8',
        'BrowserToken' : 'auth_Token'})
  }
  getProject():Observable<any>{
    return this.httpService.get<any[]>(this.dataUrl).pipe(map(data=>data));

  }



  addProject(project:projectDetails){
    // this.projectList.push(project)
    return this.httpService.post('http://localhost:8765/resourceTrackerTool/ProjectMasterApi/addProjectMaster',project,this.httpOptions);
  }
  
  
  
  deleteProject(project:projectDetails){
    return this.httpService.post('http://localhost:8765/resourceTrackerTool/ProjectMasterApi/deleteProjectMaster',project,this.httpOptions).subscribe(data => {
      this.postData = data;
  });
  }

  editProject(project:projectDetails){
    return this.httpService.post('http://localhost:8765/resourceTrackerTool/ProjectMasterApi/updateProjectMaster/'+project.woname,project,this.httpOptions);
  }
}