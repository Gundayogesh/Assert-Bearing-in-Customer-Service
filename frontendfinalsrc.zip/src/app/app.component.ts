import { Component } from '@angular/core';
import { MatDialog } from '@angular/material';
import { UploadExcelComponent } from './upload-excel/upload-excel.component';
import { TimeSheetComponent } from './time-sheet/time-sheet.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo1';
  isPopupOpened=false;
 currentUserLoginStatus: boolean = false;
  constructor(private dialog?:MatDialog){ 
    if(sessionStorage.getItem("user")!=null)
      {
        this.currentUserLoginStatus =true;
          // this.router.navigate(["login"])

      }
  }
  onClick(){
    this.isPopupOpened=true
    const dialogRef=this.dialog.open(UploadExcelComponent,{
      width: '480px',
      data:{}
    }
      )
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    })
  }
  logout() {

    console.log("logged out!")
    this.currentUserLoginStatus = false;
    sessionStorage.clear();
    
  }


  onTimeSheetClick()
  {
    this.isPopupOpened=true
    const dialogRef=this.dialog.open(TimeSheetComponent,{
      width: '480px',
      data:{}
    })
    
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    })

  }

}
