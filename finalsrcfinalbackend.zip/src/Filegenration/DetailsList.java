//package Filegenration;
//
//import java.util.ArrayList;
//import java.util.List;
//
//
//
//
//
//
//
//
//
//
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.infy.resourcemanagement.dao.CostEntityDAO;
//import com.infy.resourcemanagement.dao.ProjectMasterDAO;
//import com.infy.resourcemanagement.dao.ResourceMasterDAO;
//import com.infy.resourcemanagement.model.Cost;
//import com.infy.resourcemanagement.model.ProjectMaster;
//import com.infy.resourcemanagement.model.ResourceMaster;
//import com.infy.resourcemanagement.service.CostService;
//import com.infy.resourcemanagement.service.ProjectMasterService;
//import com.infy.resourcemanagement.service.ResourceMasterService;
//import com.infy.resourcemanagement.utility.ContextFactory;
//
//public class DetailsList {
//	
//	@Autowired
//	private static CostEntityDAO ced;
//	@Autowired
//	private static ProjectMasterDAO pmd;
//	@Autowired
//	private static ResourceMasterDAO rmd;
//	static CostService costService = (CostService) ContextFactory
//			.getContext().getBean("costService");
//	static ProjectMasterService projectMasterService = (ProjectMasterService) ContextFactory
//			.getContext().getBean("projectMasterService");
//	static ResourceMasterService resourceMasterService = (ResourceMasterService) ContextFactory
//			.getContext().getBean("resourceMasterService");
//	
//	public static void main(String[] args) throws Exception {
//		
//		
//		List<Details> d=getListBook();
//		
//		Writeexcel excelWriter=new Writeexcel();
//		String excelFilePath = "D:/Createavvavaybabu.xls";
//		 
//		excelWriter.writeDataToExcel(d, excelFilePath);
//	}
//	
//	private static List<Details> getListBook() throws Exception {
//		
//		List<Details> d=new ArrayList<>();
//		ResourceMaster resource=new ResourceMaster();
//		System.out.println("sdf");
//		List<Cost> cost=costService.getALLCostEntity();
//		System.out.println(cost.size());
//	    List<ResourceMaster> resourceMaster=resourceMasterService.getallResources();
//	    List<ProjectMaster> projectmaster=projectMasterService.getAllProjects();
//	    
//	    Double amountTilldate;
//	    int f=0;
//	    for(ResourceMaster r:resourceMaster)
//	    {
//	    	Details details=new Details();
//	    	for(Cost c:cost)
//	    	{
//	    		if(c.getEmpNo().equals(r.getEmpNo()))
//	    		{
//	    			if(f==0)
//	    			{
//	    				amountTilldate=costService.amountTillDateService(c);
//	    				f=1;
//	    				details.setAmountTillDate(amountTilldate);
//	    			}
//	    			System.out.println("2334");
//	    			System.out.println(c.getNoOfHours());
//	    			if(c.getNoOfHours()==null)
//	    			{
//	    				c.setNoOfHours(0d);
//	    			}
//	    			System.out.println(c.getMonth());
//	    			if(c.getMonth().toUpperCase().equals("JAN"))
//	    				details.setJan(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("FEB"))
//	    				details.setFeb(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("MAR"))
//	    				details.setMar(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("APR"))
//	    				details.setApr(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("MAY"))
//	    				details.setMay(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("JUN"))
//	    				details.setJun(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("JUL"))
//	    				details.setJul(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("AUG"))
//	    				details.setAug(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("SEP"))
//	    				details.setSep(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("OCT"))
//	    				details.setOct(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("NOV"))
//	    				details.setNov(c.getNoOfHours());
//	    			if(c.getMonth().toUpperCase().equals("DEC")
//	    					)
//	    				details.setDec(c.getNoOfHours());
//	    		}
//	    	}
//	    	for(ProjectMaster p:projectmaster)
//	    	{
//	    		if(r.getProjectCode().equals(p.getProjectCode()))
//	    		{
//	    			details.setStatus(p.getWOStatus());
//	    			details.setProjectCode(p.getProjectCode());
//	    			details.setInfyManager(r.getInfyManager());
//	    			details.setProjectId(p.getProjectId());
//	    			details.setWoName(p.getWOName());
//	    			details.setVisaManager(p.getVisaManager());
//	    			details.setEmpNo(r.getEmpNo());
//	    			details.setResourceName(r.getResourceName());
//	    			details.setUnit(r.getUnit());
//	    			details.setLOC(r.getLOC());
////	    			System.out.println(r.getRole());
////	    			System.out.println(r.getJobTier());
//	    			details.setRole(r.getRole());
//	    			details.setJobTier(r.getJobTier());
//	    			details.setRate(r.getRate());
//	    		}
//	    	}
//	    	d.add(details);
//	    }
////	    for(Details d1:d)
////	    {
////	    	System.out.println(d1.getEmpNo());
////	    	System.out.println(d1.getJan());
////	    	System.out.println(d1.getRole());
////	    	System.out.println(d1.getJobTier());
////	    	System.out.println(d1.getNov());
////	   
////	    }
//	    return d;
//	}
//
//}
