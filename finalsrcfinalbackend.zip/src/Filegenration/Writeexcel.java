package Filegenration;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.model.Sheet;
import org.apache.poi.hssf.model.Workbook;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class Writeexcel {
	
	
	
	public void writeDataToExcel(List<Details> listBook, String excelFilePath) throws IOException {
		 XSSFWorkbook workbook = new XSSFWorkbook();
	        XSSFSheet sheet = workbook.createSheet("Java Books");
	        
	        createHeaderRow( sheet);
	    
	    int rowCount = 0;
	 
	    for (Details aBook : listBook) {
	        XSSFRow row = sheet.createRow(++rowCount);
	        writeBook(aBook, row);
	    }
	    for(int i=0;i<26;i++)
	    	sheet.autoSizeColumn(i);
	    try (FileOutputStream outputStream = new FileOutputStream(excelFilePath)) {
	        workbook.write(outputStream);
	    }
	}

	private void createHeaderRow(XSSFSheet sheet) {
		// TODO Auto-generated method stub
	    XSSFCellStyle cellStyle = sheet.getWorkbook().createCellStyle();
	    XSSFFont font = sheet.getWorkbook().createFont();
	    font.setBold(true);
	    cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
//	    cellStyle.setWrapText(true);
//	    font.setColor(XSSFColor.);
	    font.setFontHeightInPoints((short) 12);
	    font.setColor(IndexedColors.WHITE.getIndex());
	    cellStyle.setFont(font);
	    cellStyle.setFillBackgroundColor(IndexedColors.BLUE.getIndex());
	    cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND); 
	    
	    
	    XSSFRow row = sheet.createRow(0);
	    XSSFCell cellTitle = row.createCell(0);
	 
	    cellTitle.setCellStyle(cellStyle);
	    cellTitle.setCellValue("Status");
	 
	    XSSFCell cellprojectCode = row.createCell(1);
	    cellprojectCode.setCellStyle(cellStyle);
	    cellprojectCode.setCellValue("Project Code");
	    
	 
	    XSSFCell cellWorkOrderManager = row.createCell(2);
	    cellWorkOrderManager.setCellStyle(cellStyle);
	    cellWorkOrderManager.setCellValue("Work Order manager");
	    
	    XSSFCell cellPrjectId = row.createCell(3);
	    cellPrjectId.setCellStyle(cellStyle);
	    cellPrjectId.setCellValue("PO#");
	    
	    XSSFCell cellPrjectId1 = row.createCell(4);
	    cellPrjectId1.setCellStyle(cellStyle);
	    cellPrjectId1.setCellValue("WOName");
	    
	    XSSFCell cellPrjectId5 = row.createCell(5);
	    cellPrjectId5.setCellStyle(cellStyle);
	    cellPrjectId5.setCellValue("Resource Manager");
	    
	    XSSFCell cellPrjectId6 = row.createCell(6);
	    cellPrjectId6.setCellStyle(cellStyle);
	    cellPrjectId6.setCellValue("EmpNo");
	    
	    XSSFCell cellPrjectId7 = row.createCell(7);
	    cellPrjectId7.setCellStyle(cellStyle);
	    cellPrjectId7.setCellValue("Resource Name");
	    
	    XSSFCell cellPrjectId8 = row.createCell(8);
	    cellPrjectId8.setCellStyle(cellStyle);
	    cellPrjectId8.setCellValue("Unit");
	    
	    XSSFCell cellPrjectId9 = row.createCell(9);
	    cellPrjectId9.setCellStyle(cellStyle);
	    cellPrjectId9.setCellValue("LOC");
	    
	    XSSFCell cellPrjectId10 = row.createCell(10);
	    cellPrjectId10.setCellStyle(cellStyle);
	    cellPrjectId10.setCellValue("Role");
	    
	    XSSFCell cellPrjectId11 = row.createCell(11);
	    cellPrjectId11.setCellStyle(cellStyle);
	    cellPrjectId11.setCellValue("JobTier");
	    
	    XSSFCell cellPrjectId12 = row.createCell(12);
	    cellPrjectId12.setCellStyle(cellStyle);
	    cellPrjectId12.setCellValue("Rate");
	    
	    XSSFCell cellPrjectId22 = row.createCell(13);
	    cellPrjectId22.setCellStyle(cellStyle);
	    cellPrjectId22.setCellValue("OCT");
	    
	    XSSFCell cellPrjectId23 = row.createCell(14);
	    cellPrjectId23.setCellStyle(cellStyle);
	    cellPrjectId23.setCellValue("NOV");
	    
	    XSSFCell cellPrjectId24 = row.createCell(15);
	    cellPrjectId24.setCellStyle(cellStyle);
	    cellPrjectId24.setCellValue("DEC");
	    
	    XSSFCell cellPrjectId13 = row.createCell(16);
	    cellPrjectId13.setCellStyle(cellStyle);
	    cellPrjectId13.setCellValue("JAN");
	    
	    XSSFCell cellPrjectId14 = row.createCell(17);
	    cellPrjectId14.setCellStyle(cellStyle);
	    cellPrjectId14.setCellValue("FEB");
	    
	    XSSFCell cellPrjectId15 = row.createCell(18);
	    cellPrjectId15.setCellStyle(cellStyle);
	    cellPrjectId15.setCellValue("MAR");
	    
	    XSSFCell cellPrjectId16 = row.createCell(19);
	    cellPrjectId16.setCellStyle(cellStyle);
	    cellPrjectId16.setCellValue("APR");
	    
	    
	    XSSFCell cellPrjectId17 = row.createCell(20);
	    cellPrjectId17.setCellStyle(cellStyle);
	    cellPrjectId17.setCellValue("MAY");
	    
	    XSSFCell cellPrjectId18 = row.createCell(21);
	    cellPrjectId18.setCellStyle(cellStyle);
	    cellPrjectId18.setCellValue("JUN");
	    
	    XSSFCell cellPrjectId19 = row.createCell(22);
	    cellPrjectId19.setCellStyle(cellStyle);
	    cellPrjectId19.setCellValue("JUL");
	    
	    XSSFCell cellPrjectId20 = row.createCell(23);
	    cellPrjectId20.setCellStyle(cellStyle);
	    cellPrjectId20.setCellValue("AUG");
	    
	    XSSFCell cellPrjectId21 = row.createCell(24);
	    cellPrjectId21.setCellStyle(cellStyle);
	    cellPrjectId21.setCellValue("SEP");
	    
	   
	    
	    XSSFCell cellPrjectId25 = row.createCell(25);
	    cellPrjectId25.setCellStyle(cellStyle);
	    cellPrjectId25.setCellValue("AMOUNT TILL DATE");
	    
	    
	    
	    
	    
	    
	}

		
	

	private void writeBook(Details aBook, XSSFRow row) {
		
		
		    XSSFCell cell = row.createCell(0);
		    cell.setCellValue(aBook.getStatus());
		 
		    cell = row.createCell(1);
		    cell.setCellValue(aBook.getProjectCode());
		 
		    cell = row.createCell(2);
		    cell.setCellValue(aBook.getInfyManager());
		   
		    
		    cell = row.createCell(3);
		    cell.setCellValue(aBook.getProjectId());
		    
		    cell = row.createCell(4);
		    cell.setCellValue(aBook.getWoName());
		    
		    cell = row.createCell(5);
		    cell.setCellValue(aBook.getVisaManager());
		    
		    cell = row.createCell(6);
		    cell.setCellValue(aBook.getEmpNo());
		    
		    cell = row.createCell(7);
		    cell.setCellValue(aBook.getResourceName());
		    
		    cell = row.createCell(8);
		    cell.setCellValue(aBook.getUnit());
		    
		    cell = row.createCell(9);
		    cell.setCellValue(aBook.getLOC());
		    
		    cell = row.createCell(10);
		    cell.setCellValue(aBook.getRole());
		    
		    cell = row.createCell(11);
		    cell.setCellValue(aBook.getJobTier());
		    
		    cell = row.createCell(12);
		    cell.setCellValue(aBook.getRate());
		    
		    cell = row.createCell(13);
		   
		   cell.setCellValue(aBook.getOct());
		    
		    cell = row.createCell(14);
		    cell.setCellValue(aBook.getNov());
		    
		    cell = row.createCell(15);
		    cell.setCellValue(aBook.getDec());
		    
		    cell = row.createCell(16);
		    cell.setCellValue(aBook.getJan());
		    
		    cell = row.createCell(17);
		    cell.setCellValue(aBook.getFeb());
		    
		    cell = row.createCell(18);
		    cell.setCellValue(aBook.getMar());
		    
		    cell = row.createCell(19);
		    cell.setCellValue(aBook.getApr());
		    
		    cell = row.createCell(20);
		    cell.setCellValue(aBook.getMay());
		    
		    cell = row.createCell(21);
		    cell.setCellValue(aBook.getJun());
		    
		    cell = row.createCell(22);
		    cell.setCellValue(aBook.getJul());
		    
		    cell = row.createCell(23);
		    cell.setCellValue(aBook.getAug());
		    
		    cell = row.createCell(24);
		    cell.setCellValue(aBook.getSep());
		    
		    cell = row.createCell(25);
		    cell.setCellValue(aBook.getAmountTillDate());
		    
		
	}
	
	

}
