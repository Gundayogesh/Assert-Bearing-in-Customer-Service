package com.infy.resourcemanagement.model;

public class Graph {

	private String WOName;
	private Double TotalAmount;
	private Double AmountTilldate;
	public String getWOName() {
		return WOName;
	}
	public void setWOName(String wOName) {
		WOName = wOName;
	}
	public Double getTotalAmount() {
		return TotalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		TotalAmount = totalAmount;
	}
	public Double getAmountTilldate() {
		return AmountTilldate;
	}
	public void setAmountTilldate(Double amountTilldate) {
		AmountTilldate = amountTilldate;
	}
	
	
}
