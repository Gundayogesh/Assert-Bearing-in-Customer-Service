package com.infy.resourcemanagement.model;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.Id;

import com.infy.resourcemanagement.entity.ResourceMasterEntity;

public class ProjectMaster {
	private String CW;
	private String projectId;
	
	private String WOName;
	private Integer RTN;
	private String visaManager;
	private String visaDM;
	private String functionalHead;
	private String SVP;
	private Integer costcenter;
	private Integer amount;
	private String costType;
	private String projectType;
	private LocalDate startDate;
	private LocalDate endDate;
	private LocalDate dateSubmitted;
	private String WOStatus;
	private String clientServiceManager;
	private String portfolio;
	private Integer oppID;
	private Double WOVersion;
	private String projectCode;
	private String message;
	
	
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getCW() {
		return CW;
	}
	public void setCW(String cW) {
		CW = cW;
	}
	public String getWOName() {
		return WOName;
	}
	public void setWOName(String wOName) {
		WOName = wOName;
	}
	public Integer getRTN() {
		return RTN;
	}
	public void setRTN(Integer rTN) {
		RTN = rTN;
	}
	public String getVisaManager() {
		return visaManager;
	}
	public void setVisaManager(String visaManager) {
		this.visaManager = visaManager;
	}
	public String getVisaDM() {
		return visaDM;
	}
	public void setVisaDM(String visaDM) {
		this.visaDM = visaDM;
	}
	public String getFunctionalHead() {
		return functionalHead;
	}
	public void setFunctionalHead(String functionalHead) {
		this.functionalHead = functionalHead;
	}
	public String getSVP() {
		return SVP;
	}
	public void setSVP(String sVP) {
		SVP = sVP;
	}
	public Integer getCostcenter() {
		return costcenter;
	}
	public void setCostcenter(Integer costcenter) {
		this.costcenter = costcenter;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public String getCostType() {
		return costType;
	}
	public void setCostType(String costType) {
		this.costType = costType;
	}
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public LocalDate getDateSubmitted() {
		return dateSubmitted;
	}
	public void setDateSubmitted(LocalDate dateSubmitted) {
		this.dateSubmitted = dateSubmitted;
	}
	public String getWOStatus() {
		return WOStatus;
	}
	public void setWOStatus(String wOStatus) {
		WOStatus = wOStatus;
	}
	public String getClientServiceManager() {
		return clientServiceManager;
	}
	public void setClientServiceManager(String clientServiceManager) {
		this.clientServiceManager = clientServiceManager;
	}
	public String getPortfolio() {
		return portfolio;
	}
	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}
	public Integer getOppID() {
		return oppID;
	}
	public void setOppID(Integer oppID) {
		this.oppID = oppID;
	}
	public Double getWOVersion() {
		return WOVersion;
	}
	public void setWOVersion(Double wOVersion) {
		WOVersion = wOVersion;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private List<ResourceMasterEntity> resource;
	
	public List<ResourceMasterEntity> getResource() {
		return resource;
	}
	public void setResource(List<ResourceMasterEntity> resource) {
		this.resource = resource;
	}
	
	
}
