package com.infy.resourcemanagement.model;

public class Cost {
	
	private String status;
	
	private String projectId;
	private Integer empNo;
	private String woName;

	//private Integer visaNumber;
	private String resourceName;
	private String unit;
	private String LOC;
//	private String city;
	//private String primarySkill;
	//private String secondarySkill;
	private String visaManager;
	private String infyManager;
	private String projectCode;
	private Double rate;
	private double amountTillDate;
	private String role;
	private String jobTier;
	private Double Jan=0d;
	private Double Feb=0d;
	private Double Mar=0d;
	private Double Apr=0d;
	private Double May=0d;
	private Double Jun=0d;
	private Double Jul=0d;
	private Double Aug=0d;
	private Double Sep=0d;
	private Double Oct=0d;
	private Double Nov=0d;
	private Double Dec=0d;
	private String message;
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Double getJan() {
		return Jan;
	}
	public void setJan(Double jan) {
		Jan = jan;
	}
	public Double getFeb() {
		return Feb;
	}
	public void setFeb(Double feb) {
		Feb = feb;
	}
	public Double getMar() {
		return Mar;
	}
	public void setMar(Double mar) {
		Mar = mar;
	}
	public Double getApr() {
		return Apr;
	}
	public void setApr(Double apr) {
		Apr = apr;
	}
	public Double getMay() {
		return May;
	}
	public void setMay(Double may) {
		May = may;
	}
	public Double getJun() {
		return Jun;
	}
	public void setJun(Double jun) {
		Jun = jun;
	}
	public Double getJul() {
		return Jul;
	}
	public void setJul(Double jul) {
		Jul = jul;
	}
	public Double getAug() {
		return Aug;
	}
	public void setAug(Double aug) {
		Aug = aug;
	}
	public Double getSep() {
		return Sep;
	}
	public void setSep(Double sep) {
		Sep = sep;
	}
	public Double getOct() {
		return Oct;
	}
	public void setOct(Double oct) {
		Oct = oct;
	}
	public Double getNov() {
		return Nov;
	}
	public void setNov(Double nov) {
		Nov = nov;
	}
	public Double getDec() {
		return Dec;
	}
	public void setDec(Double dec) {
		Dec = dec;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getJobTier() {
		return jobTier;
	}
	public void setJobTier(String jobTier) {
		this.jobTier = jobTier;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public Integer getEmpNo() {
		return empNo;
	}
	public void setEmpNo(Integer empNo) {
		this.empNo = empNo;
	}
	public String getWoName() {
		return woName;
	}
	public void setWoName(String woName) {
		this.woName = woName;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getLOC() {
		return LOC;
	}
	public void setLOC(String lOC) {
		LOC = lOC;
	}
//	public String getCity() {
//		return city;
//	}
//	public void setCity(String city) {
//		this.city = city;
//	}
	public String getVisaManager() {
		return visaManager;
	}
	public void setVisaManager(String visaManager) {
		this.visaManager = visaManager;
	}
	public String getInfyManager() {
		return infyManager;
	}
	public void setInfyManager(String infyManager) {
		this.infyManager = infyManager;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public Double getRate() {
		return rate;
	}
	public void setRate(Double rate) {
		this.rate = rate;
	}
	public double getAmountTillDate() {
		return amountTillDate;
	}
	public void setAmountTillDate(double amountTillDate) {
		this.amountTillDate = amountTillDate;
	}
	
	
	

}
