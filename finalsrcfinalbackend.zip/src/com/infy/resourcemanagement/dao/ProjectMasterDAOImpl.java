package com.infy.resourcemanagement.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;




import com.infy.resourcemanagement.entity.ProjectMasterEntity;

import com.infy.resourcemanagement.model.ProjectMaster;



@Repository(value = "projectMasterDAO")
public class ProjectMasterDAOImpl implements ProjectMasterDAO{
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public ProjectMaster getProjectMaster(String WOName) throws Exception {
		ProjectMaster projectMaster=null;
		Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProjectMasterEntity> criteriaQuery = builder
				.createQuery(ProjectMasterEntity.class);
		
		Root<ProjectMasterEntity> root = criteriaQuery.from(ProjectMasterEntity.class);
		criteriaQuery.select(root);
		
		criteriaQuery.where(builder.equal(root.get("WOName"), WOName));
		
//		ProjectMasterEntity pme = session.get(ProjectMasterEntity.class,gwnNumber);
		ProjectMasterEntity pme= session.createQuery(criteriaQuery).getSingleResult();
		
		if (pme != null) {
			projectMaster = new ProjectMaster();
			projectMaster.setProjectId(pme.getProjectId());
			projectMaster.setAmount(pme.getAmount());
			projectMaster.setClientServiceManager(pme.getClientServiceManager());
			projectMaster.setCostcenter(pme.getCostcenter());
			projectMaster.setCostType(pme.getCostType());
			projectMaster.setCW(pme.getCW());
			projectMaster.setDateSubmitted(pme.getDateSubmitted());
			projectMaster.setEndDate(pme.getEndDate());
			projectMaster.setFunctionalHead(pme.getFunctionalHead());
			projectMaster.setOppID(pme.getOppID());
			projectMaster.setPortfolio(pme.getPortfolio());
			projectMaster.setProjectCode(pme.getProjectCode());
			projectMaster.setProjectType(pme.getProjectType());
			projectMaster.setRTN(pme.getRTN());
			projectMaster.setStartDate(pme.getStartDate());
			projectMaster.setVisaDM(pme.getVisaDM());
			projectMaster.setSVP(pme.getSVP());
			projectMaster.setVisaManager(pme.getVisaManager());
			projectMaster.setWOName(pme.getWOName());
			projectMaster.setWOStatus(pme.getWOStatus());
			projectMaster.setWOVersion(pme.getWOVersion());
			
		}

		return projectMaster;
	}

	
	@Override
	public ProjectMaster getProjectMasterByProjectCode(String projectCode) throws Exception {
		ProjectMaster projectMaster=null;
		System.out.println("uiofdfhiosdglr'goagohhdgggggggestfesgeddsghdfhfhh"+projectCode);
		Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProjectMasterEntity> criteriaQuery = builder
				.createQuery(ProjectMasterEntity.class);
		
		Root<ProjectMasterEntity> root = criteriaQuery.from(ProjectMasterEntity.class);
		criteriaQuery.select(root);
		
		criteriaQuery.where(builder.equal(root.get("projectCode"), projectCode));
		
//		ProjectMasterEntity pme = session.get(ProjectMasterEntity.class,gwnNumber);
		ProjectMasterEntity pme= session.createQuery(criteriaQuery).getSingleResult();
		
		if (pme != null) {
			projectMaster = new ProjectMaster();
			projectMaster.setProjectId(pme.getProjectId());
			projectMaster.setAmount(pme.getAmount());
			projectMaster.setClientServiceManager(pme.getClientServiceManager());
			projectMaster.setCostcenter(pme.getCostcenter());
			projectMaster.setCostType(pme.getCostType());
			projectMaster.setCW(pme.getCW());
			projectMaster.setDateSubmitted(pme.getDateSubmitted());
			projectMaster.setEndDate(pme.getEndDate());
			projectMaster.setFunctionalHead(pme.getFunctionalHead());
			projectMaster.setOppID(pme.getOppID());
			projectMaster.setPortfolio(pme.getPortfolio());
			projectMaster.setProjectCode(pme.getProjectCode());
			projectMaster.setProjectType(pme.getProjectType());
			projectMaster.setRTN(pme.getRTN());
			projectMaster.setStartDate(pme.getStartDate());
			projectMaster.setVisaDM(pme.getVisaDM());
			projectMaster.setSVP(pme.getSVP());
			projectMaster.setVisaManager(pme.getVisaManager());
			projectMaster.setWOName(pme.getWOName());
			projectMaster.setWOStatus(pme.getWOStatus());
			projectMaster.setWOVersion(pme.getWOVersion());
			
		}

		return projectMaster;
	}

	@Override
	public String addProjectMaster(ProjectMaster project) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		ProjectMasterEntity projectMaster=new ProjectMasterEntity();
		System.out.println("2");
		if(project!=null)
		{
			projectMaster.setProjectId(project.getProjectId());
			projectMaster.setAmount(project.getAmount());
			projectMaster.setClientServiceManager(project.getClientServiceManager());
			projectMaster.setCostcenter(project.getCostcenter());
			projectMaster.setCostType(project.getCostType());
			projectMaster.setCW(project.getCW());
			projectMaster.setDateSubmitted(project.getDateSubmitted());
			projectMaster.setEndDate(project.getEndDate());
			projectMaster.setFunctionalHead(project.getFunctionalHead());
			projectMaster.setOppID(project.getOppID());
			projectMaster.setPortfolio(project.getPortfolio());
			projectMaster.setProjectCode(project.getProjectCode());
			projectMaster.setProjectType(project.getProjectType());
			projectMaster.setRTN(project.getRTN());
			projectMaster.setStartDate(project.getStartDate());
			projectMaster.setVisaDM(project.getVisaDM());
			projectMaster.setSVP(project.getSVP());
			projectMaster.setVisaManager(project.getVisaManager());
			projectMaster.setWOName(project.getWOName());
			projectMaster.setWOStatus(project.getWOStatus());
			projectMaster.setWOVersion(project.getWOVersion());
			projectMaster.setResource(project.getResource());
						
			return (String) session.save(projectMaster);
		}
		return null;
	}

	@Override
	public void updateProjectMaster(ProjectMaster project) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		ProjectMasterEntity projectMaster = (ProjectMasterEntity) session.get(ProjectMasterEntity.class,
				project.getWOName());
		if (projectMaster != null) {
			projectMaster.setProjectId(project.getProjectId());
			projectMaster.setAmount(project.getAmount());
			projectMaster.setClientServiceManager(project.getClientServiceManager());
			projectMaster.setCostcenter(project.getCostcenter());
			projectMaster.setCostType(project.getCostType());
			projectMaster.setCW(project.getCW());
			projectMaster.setDateSubmitted(project.getDateSubmitted());
			projectMaster.setEndDate(project.getEndDate());
			projectMaster.setFunctionalHead(project.getFunctionalHead());
			projectMaster.setOppID(project.getOppID());
			projectMaster.setPortfolio(project.getPortfolio());
			projectMaster.setProjectCode(project.getProjectCode());
			projectMaster.setProjectType(project.getProjectType());
			projectMaster.setRTN(project.getRTN());
			projectMaster.setStartDate(project.getStartDate());
			projectMaster.setVisaDM(project.getVisaDM());
			projectMaster.setSVP(project.getSVP());
			projectMaster.setVisaManager(project.getVisaManager());
			projectMaster.setWOName(project.getWOName());
			projectMaster.setWOStatus(project.getWOStatus());
			projectMaster.setWOVersion(project.getWOVersion());
		}
		
	}
	


	@Override
	public void deleteProjectMaster(String projectName) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();

		ProjectMasterEntity pme=(ProjectMasterEntity)session.get(ProjectMasterEntity.class, projectName);
		if (pme != null) {

			session.delete(pme);

		}
		else
		{
			throw new Exception("Service.PROJECT_MASTER_NOT_FOUND");
		}
	}
	@Override
	public List<ProjectMaster> getAllProjects()throws Exception{
		
		List<ProjectMaster> projects =new ArrayList<>();
       Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProjectMasterEntity> criteriaQuery = builder
				.createQuery(ProjectMasterEntity.class);
		
		Root<ProjectMasterEntity> root = criteriaQuery.from(ProjectMasterEntity.class);
		criteriaQuery.select(root);
		List<ProjectMasterEntity> projectMasterEntityList = session.createQuery(criteriaQuery).list();
		for(ProjectMasterEntity project:projectMasterEntityList){
			ProjectMaster projectMaster=new ProjectMaster();
			projectMaster.setProjectId(project.getProjectId());
			projectMaster.setAmount(project.getAmount());
			projectMaster.setClientServiceManager(project.getClientServiceManager());
			projectMaster.setCostcenter(project.getCostcenter());
			projectMaster.setCostType(project.getCostType());
			projectMaster.setCW(project.getCW());
			projectMaster.setDateSubmitted(project.getDateSubmitted());
			projectMaster.setEndDate(project.getEndDate());
			projectMaster.setFunctionalHead(project.getFunctionalHead());
			projectMaster.setOppID(project.getOppID());
			projectMaster.setPortfolio(project.getPortfolio());
			projectMaster.setProjectCode(project.getProjectCode());
			projectMaster.setProjectType(project.getProjectType());
			projectMaster.setRTN(project.getRTN());
			projectMaster.setStartDate(project.getStartDate());
			projectMaster.setVisaDM(project.getVisaDM());
			projectMaster.setSVP(project.getSVP());
			projectMaster.setVisaManager(project.getVisaManager());
			projectMaster.setWOName(project.getWOName());
			projectMaster.setWOStatus(project.getWOStatus());
			projectMaster.setWOVersion(project.getWOVersion());
			
			projects.add(projectMaster);
			
			
			
		}
		return projects;
		
	}

	
	
	
}
