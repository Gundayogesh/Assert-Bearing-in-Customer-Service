package com.infy.resourcemanagement.dao;

import java.util.List;

import com.infy.resourcemanagement.model.ProjectMaster;

public interface ProjectMasterDAO {
	 ProjectMaster getProjectMaster(String projectName) throws Exception;

	 String addProjectMaster(ProjectMaster project) throws Exception;

	 void updateProjectMaster(ProjectMaster project) throws Exception;

	 void deleteProjectMaster(String projectName) throws Exception;

	List<ProjectMaster> getAllProjects() throws Exception;

	ProjectMaster getProjectMasterByProjectCode(String projectCode)
			throws Exception;


}
