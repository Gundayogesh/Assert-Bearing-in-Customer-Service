package com.infy.resourcemanagement.dao;

import java.util.List;

import com.infy.resourcemanagement.model.ResourceMaster;

public interface ResourceMasterDAO {
	public ResourceMaster getResourceMaster(Integer empNo) throws Exception;

	public Integer addResourceMaster(ResourceMaster resource) throws Exception;

	public void updateResourceMaster(ResourceMaster resource) throws Exception;

	public void deleteResourceMaster(Integer empNo) throws Exception;

	public List<ResourceMaster> getResourceByVisaManager(String visaManager) throws Exception;

	public List<ResourceMaster> getResourceByProjectCode(String projectCode) throws Exception;
	
	public List<ResourceMaster> getAllResources() throws Exception;

	

}
