package com.infy.resourcemanagement.dao;

import java.io.File;
import java.io.FileInputStream;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.resourcemanagement.entity.CostEntity;
import com.infy.resourcemanagement.entity.ProjectMasterEntity;
import com.infy.resourcemanagement.entity.ResourceMasterEntity;
import com.infy.resourcemanagement.model.Cost;
import com.infy.resourcemanagement.model.Graph;
import com.infy.resourcemanagement.model.ProjectMaster;
import com.infy.resourcemanagement.model.ResourceMaster;


@Repository(value = "costEntityDAO")
public class CostEntityDAO {
                @Autowired
                SessionFactory sessionFactory;
                @Autowired
                private ProjectMasterDAO pmd;
                @Autowired
                private ResourceMasterDAO rmd;
                
                public void addTimesheetForNewResource(ResourceMaster r)throws Exception{   
                	 System.out.println("yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy");
               ProjectMaster pm=pmd.getProjectMasterByProjectCode(r.getProjectCode());
    			System.out.println("uysdguisflgdio;sghrg;df;lkghdfio'gjndfl;gn'dlghnjo'");
    				Cost c=new Cost();
    				c.setStatus(pm.getWOStatus());
    				c.setProjectCode(pm.getProjectCode());
    				c.setInfyManager(pm.getClientServiceManager());
    				c.setProjectId(pm.getProjectId());
    				c.setWoName(pm.getWOName());
    				c.setVisaManager(pm.getVisaManager());
    				c.setEmpNo(r.getEmpNo());
    				c.setResourceName(r.getResourceName());
    				c.setUnit(r.getUnit());
    				c.setLOC(r.getLOC());
    				System.out.println("xyz");
    				System.out.println(r.getRole());
    				System.out.println(r.getJobTier());
    				System.out.println("pqr");
    				c.setRole(r.getRole());
    				c.setJobTier(r.getJobTier());
    				c.setRate(r.getRate());
    				c.setJan(0d);
    				c.setFeb(0d);
    				c.setMar(0d);
    				c.setApr(0d);
    				c.setMay(0d);
    				c.setJun(0d);
    				c.setJul(0d);
    				c.setAug(0d);
    				c.setSep(0d);
    				c.setOct(0d);
    				c.setNov(0d);
    				c.setDec(0d);
    				c.setAmountTillDate(0d);
    				this.addTimesheet(c);
    			}
    			
                
                
                
                public void addTimesheet(Cost k)throws Exception{
                                
                                Session session = sessionFactory.getCurrentSession();
                                Double rate=0d;
                                CostEntity cost1=new CostEntity();
                                if(k!=null)
                                { 
                                	
                                	System.out.println("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb");
                                                cost1.setAmountTillDate(k.getAmountTillDate());
                                                cost1.setApr(k.getApr());
                                                cost1.setAug(k.getAug());
                                                cost1.setDec(k.getDec());
                                                cost1.setEmpNo(k.getEmpNo());
                                                cost1.setFeb(k.getFeb());
                                                cost1.setInfyManager(k.getInfyManager());
                                                cost1.setJan(k.getJan());
                                                cost1.setJobTier(k.getJobTier());
                                                cost1.setJul(k.getJul());
                                                cost1.setJun(k.getJun());
                                                cost1.setLOC(k.getLOC());
                                                cost1.setMar(k.getMar());
                                                cost1.setMay(k.getMay());
                                                cost1.setNov(k.getNov());
                                                cost1.setOct(k.getOct());
                                                cost1.setProjectCode(k.getProjectCode());
                                                cost1.setProjectId(k.getProjectId());
                                                cost1.setRate(k.getRate());
                                                cost1.setResourceName(k.getResourceName());
                                                cost1.setRole(k.getRole());
                                                cost1.setSep(k.getSep());
                                                cost1.setStatus(k.getStatus());
                                                cost1.setUnit(k.getUnit());
                                                cost1.setVisaManager(k.getVisaManager());
                                                cost1.setWoName(k.getWoName());
                                              System.out.println("yogeshhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");

                                                session.persist(cost1);
                                }
                                                
                
   
   }
                
                
                public void updateTimesheet(List<Cost> costList)throws Exception{
                                
                                Session session = sessionFactory.getCurrentSession();
                                Double rate=0d;
                                //CostEntity cost1=new CostEntity();
                                if(costList.size()!=0)
                               {
                                for(Cost k:costList)
                                    {
                                                
                                                                CostEntity cost1 = (CostEntity) session.get(CostEntity.class,
                                                                                                k.getEmpNo());
                                                                System.out.println(costList.size());
                                                                System.out.println("HYE");
                                                                cost1.setAmountTillDate(k.getAmountTillDate());
                                                                cost1.setApr(k.getApr());
                                                                cost1.setAug(k.getAug());
                                                                cost1.setDec(k.getDec());
                                                                cost1.setEmpNo(k.getEmpNo());
                                                                cost1.setFeb(k.getFeb());
                                                                cost1.setInfyManager(k.getInfyManager());
                                                                cost1.setJan(k.getJan());
                                                                cost1.setJobTier(k.getJobTier());
                                                                cost1.setJul(k.getJul());
                                                                cost1.setJun(k.getJun());
                                                                cost1.setLOC(k.getLOC());
                                                                cost1.setMar(k.getMar());
                                                                cost1.setMay(k.getMay());
                                                                cost1.setNov(k.getNov());
                                                                cost1.setOct(k.getOct());
                                                                cost1.setProjectCode(k.getProjectCode());
                                                                cost1.setProjectId(k.getProjectId());
                                                                cost1.setRate(k.getRate());
                                                                cost1.setResourceName(k.getResourceName());
                                                                cost1.setRole(k.getRole());
                                                                cost1.setSep(k.getSep());
                                                                cost1.setStatus(k.getStatus());
                                                                cost1.setUnit(k.getUnit());
                                                                cost1.setVisaManager(k.getVisaManager());
                                                                cost1.setWoName(k.getWoName());
                                                                if(k.getProjectCode()!=null)
                                                                {
//                                                                            System.out.println();
                                                                Double amount=amountTillDate(k);
                                                                cost1.setAmountTillDate(amount);
                                                                }
                                                                
                                    }
                               }
                                                
                
   
   }
                
   public double amountTillDate(Cost c)throws Exception
   {
                   Session session = sessionFactory.getCurrentSession();
                   CostEntity ce= new CostEntity();
                   Double empRate=0d,amountTillDate=0d;
                   double sum=0d,rate=0d;
                                if(c!=null)
                                {
                                                
                                                
                                                
                                                CriteriaBuilder builder1 = session.getCriteriaBuilder();
                                                CriteriaQuery<ResourceMasterEntity> criteriaQuery1 = builder1.createQuery(ResourceMasterEntity.class);
                                                
                                                Root<ResourceMasterEntity> root1 = criteriaQuery1.from(ResourceMasterEntity.class);
                                                criteriaQuery1.select(root1);
                                                System.out.println(c.getProjectCode());
                                                criteriaQuery1.where(builder1.equal(root1.get("projectCode"), c.getProjectCode()));
                                                List<ResourceMasterEntity> resourceMasterEntity = session.createQuery(criteriaQuery1).getResultList();
                                                for(ResourceMasterEntity r:resourceMasterEntity)
                                                {
                                                    if(r.getEmpNo().equals(c.getEmpNo()))
                                                    {
                                                                 rate=r.getRate();
                                                    }
                                                }
                                                
                                                System.out.println(rate);
                                                sum+=c.getJan()*rate;
                                                sum+=c.getFeb()*rate;
                                                sum+=c.getMar()*rate;
                                                sum+=c.getApr()*rate;
                                                sum+=c.getMay()*rate;
                                                sum+=c.getJun()*rate;
                                                sum+=c.getJul()*rate;
                                                sum+=c.getAug()*rate;
                                                sum+=c.getSep()*rate;
                                                sum+=c.getOct()*rate;
                                                sum+=c.getNov()*rate;
                                                sum+=c.getDec()*rate;
                                                return sum;
                                                
                                }
                                return 0d;
                
}
   
   public List<Graph> getAllgraphdetails() throws Exception{
                   List<ProjectMaster> li=pmd.getAllProjects();
                   List<Graph> graph=new ArrayList<>();
                   for(ProjectMaster p:li)
                   {
                       Graph g=new Graph();
                       Double d=amountTillDateByWOName(p.getProjectCode());
                       if(d==null)
                       {
                    	   System.out.println("1");
                    	   g.setAmountTilldate(0d);
                       }
                       else
                       {
                    	   System.out.println("2");
                    	   g.setAmountTilldate(d);
                       }
                       g.setTotalAmount((double) p.getAmount());
                       g.setWOName(p.getWOName());
                       graph.add(g);
                   }
                   
                   return graph;
   }
   
   public Double amountTillDateByWOName(String WOName)throws Exception
   {
	   		System.out.println(WOName);
            Session session = sessionFactory.getCurrentSession();
                                
            CriteriaBuilder builder2 = session.getCriteriaBuilder();
            CriteriaQuery<Double> criteriaQuery23 = builder2.createQuery(Double.class);
            Root<CostEntity> root23 = criteriaQuery23.from(CostEntity.class);
            criteriaQuery23.select(builder2.sum(root23.get("amountTillDate")));
            criteriaQuery23.where(builder2.equal(root23.get("projectCode"),WOName));
            Double amountTillDate = session.createQuery(criteriaQuery23).getSingleResult();
                       
            System.out.println("11");
            System.out.println(amountTillDate);
            System.out.println("12"); 
            if(amountTillDate==null)
            	return 0d;
            else
             return amountTillDate;
}
  
                public List<Cost> getAllCostEntity()throws Exception{
                                
                                List<Cost> cost =new ArrayList<>();
      Session session = sessionFactory.getCurrentSession();
                                
                                CriteriaBuilder builder = session.getCriteriaBuilder();
                                CriteriaQuery<CostEntity> criteriaQuery = builder.createQuery(CostEntity.class);
                                
                                Root<CostEntity> root = criteriaQuery.from(CostEntity.class);
                                criteriaQuery.select(root);
                                List<CostEntity> costEntityList = session.createQuery(criteriaQuery).list();
                                
                                for(CostEntity k:costEntityList){
                                                Cost cost1=new Cost();
                                                cost1.setAmountTillDate(k.getAmountTillDate());
                                                cost1.setApr(k.getApr());
                                                cost1.setAug(k.getAug());
                                                cost1.setDec(k.getDec());
                                                cost1.setEmpNo(k.getEmpNo());
                                                cost1.setFeb(k.getFeb());
                                                cost1.setInfyManager(k.getInfyManager());
                                                cost1.setJan(k.getJan());
                                                cost1.setJobTier(k.getJobTier());
                                                cost1.setJul(k.getJul());
                                                cost1.setJun(k.getJun());
                                                cost1.setLOC(k.getLOC());
                                                cost1.setMar(k.getMar());
                                                cost1.setMay(k.getMay());
                                                cost1.setNov(k.getNov());
                                                cost1.setOct(k.getOct());
                                                cost1.setProjectCode(k.getProjectCode());
                                                cost1.setProjectId(k.getProjectId());
                                                cost1.setRate(k.getRate());
                                                cost1.setResourceName(k.getResourceName());
                                                cost1.setRole(k.getRole());
                                                cost1.setSep(k.getSep());
                                                cost1.setStatus(k.getStatus());
                                                cost1.setUnit(k.getUnit());
                                                cost1.setVisaManager(k.getVisaManager());
                                                cost1.setWoName(k.getWoName());
                                                cost.add(cost1);
                                                
                                                
                                                
                                }
                                return cost;
                                
                }
                
   
   
}
                
                
//            CriteriaBuilder builder1 = session.getCriteriaBuilder();
//            CriteriaQuery<ProjectMasterEntity> criteriaQuery1 = builder1
//                                            .createQuery(ProjectMasterEntity.class);
//            
//            Root<ProjectMasterEntity> root1 = criteriaQuery1.from(ProjectMasterEntity.class);
//            criteriaQuery1.select(root1);
//            
//            criteriaQuery1.where(builder1.equal(root1.get("projectCode"), pc));
//            ProjectMasterEntity projectMasterEntity = session.createQuery(criteriaQuery1).getSingleResult();
//            ce.setWoName(projectMasterEntity.getWOName());
//            
//            System.out.println(ce.getWoName());
////        System.out.println(ce.get);
//            
//            
//            ProjectMaster pm=new ProjectMaster();
//            pm=pmd.getProjectMaster(ce.getWoName());
//            
//            System.out.println("sdlfjksdfl"+cost.getWoName());
//            List<ResourceMaster> list=new ArrayList<>();
//            list=rmd.getResourceByProjectCode(cost.getWoName());
//            System.out.println(list.size());
//            if(list.size()==0)
//            {
//                            cost.setMessage("projects are not allocated to this resource");
//                            return null;
//            }
//            for(ResourceMaster resource:list)
//            {
//                            System.out.println("1234");
//                            System.out.println(resource.getEmpNo());
//                            System.out.println(cost.getEmpNo());
//                            System.out.println("5678");
//                            if(resource.getEmpNo().equals(cost.getEmpNo()))
//                            {
//                                            System.out.println("Rate is "+resource.getRate());
//                                            System.out.println("Hours are  "+cost.getNoOfHours());
//                                            rate=resource.getRate()*cost.getNoOfHours();
//                            }
//            }
//            
//            System.out.println(rate);
//            
//            
//            
//            
//            CriteriaBuilder builder = session.getCriteriaBuilder();
//    CriteriaQuery<Double> criteriaQuery = builder.createQuery(Double.class);
//    Root<CostEntity> root = criteriaQuery.from(CostEntity.class);
//    criteriaQuery.select(builder.sum(root.get("billingAmount")));
//    Double sumofAmount= session.createQuery(criteriaQuery).getSingleResult();
//   System.out.println(sumofAmount);
//   if(sumofAmount==null)
//   {
//               sumofAmount=0d;
//   }
//   
//  if(sumofAmount+rate <=pm.getAmount())
//   {
//               
//               ce.setBillingAmount(rate);
//               cost.setBillingAmount(rate);
//               cost.setMessage("sucessfully added");
//                            session.persist(ce);
//                            return cost;
//               
//   }
//   else
//   {
//               cost.setMessage("billimg amount limit exceeded");
//   }
//            
//            
//}
//}
//
//return null;
                                                

                

