package com.infy.resourcemanagement.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.resourcemanagement.entity.ProjectMasterEntity;
import com.infy.resourcemanagement.entity.ResourceMasterEntity;
import com.infy.resourcemanagement.model.ResourceMaster;

@Repository(value = "resourceDao")
public class ResourceDAOImpl implements ResourceMasterDAO{
	@Autowired
	SessionFactory sessionFactory;
	@Override
	public ResourceMaster getResourceMaster(Integer empNo) throws Exception {
		// TODO Auto-generated method stub
		ResourceMaster resourceMaster=null;
		Session session = sessionFactory.getCurrentSession();
		ResourceMasterEntity rme = (ResourceMasterEntity) session.get(ResourceMasterEntity.class,empNo);
		if(rme!=null)
		{
			resourceMaster=new ResourceMaster();
			resourceMaster.setCity(rme.getCity());
			resourceMaster.setEmpNo(rme.getEmpNo());
			resourceMaster.setInfyManager(rme.getInfyManager());
			resourceMaster.setLOC(rme.getLOC());
			resourceMaster.setPrimarySkill(rme.getPrimarySkill());
			resourceMaster.setResourceName(rme.getResourceName());
			resourceMaster.setSecondarySkill(rme.getSecondarySkill());
			resourceMaster.setVisaManager(rme.getVisaManager());
			resourceMaster.setVisaNumber(rme.getVisaNumber());
			resourceMaster.setUnit(rme.getUnit());
			resourceMaster.setRate(rme.getRate());
			resourceMaster.setJobTier(rme.getJobTier());
			resourceMaster.setRole(rme.getRole());
		}
		return resourceMaster;
	}

	@Override
	public Integer addResourceMaster(ResourceMaster resource) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		ResourceMasterEntity resourceMaster=new ResourceMasterEntity();
		System.out.println("3");
		if(resource!=null){
			resourceMaster.setCity(resource.getCity());
			resourceMaster.setEmpNo(resource.getEmpNo());
			resourceMaster.setInfyManager(resource.getInfyManager());
			resourceMaster.setLOC(resource.getLOC());
			resourceMaster.setPrimarySkill(resource.getPrimarySkill());
			resourceMaster.setResourceName(resource.getResourceName());
			resourceMaster.setSecondarySkill(resource.getSecondarySkill());
			resourceMaster.setVisaNumber(resource.getVisaNumber());
			resourceMaster.setVisaManager(resource.getVisaManager());
			resourceMaster.setUnit(resource.getUnit());
			resourceMaster.setProjectCode(resource.getProjectCode());
			resourceMaster.setRate(resource.getRate());
			resourceMaster.setJobTier(resource.getJobTier());
			resourceMaster.setRole(resource.getRole());
			
			System.out.println("4");
			return (Integer) session.save(resourceMaster);
		}
		return null;
	}

	@Override
	public void updateResourceMaster(ResourceMaster resource) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		ResourceMasterEntity resourceMaster = (ResourceMasterEntity) session.get(ResourceMasterEntity.class,resource.getEmpNo());
		if(resourceMaster!=null){
			resourceMaster.setCity(resource.getCity());
			resourceMaster.setEmpNo(resource.getEmpNo());
			resourceMaster.setInfyManager(resource.getInfyManager());
			resourceMaster.setLOC(resource.getLOC());
			resourceMaster.setPrimarySkill(resource.getPrimarySkill());
			resourceMaster.setResourceName(resource.getResourceName());
			resourceMaster.setSecondarySkill(resource.getSecondarySkill());
			resourceMaster.setVisaManager(resource.getVisaManager());
			resourceMaster.setVisaNumber(resource.getVisaNumber());
			resourceMaster.setUnit(resource.getUnit());
			resourceMaster.setProjectCode(resource.getProjectCode());
			resourceMaster.setRate(resource.getRate());
			resourceMaster.setJobTier(resource.getJobTier());
			resourceMaster.setRole(resource.getRole());
		}
		
	}

	@Override
	public void deleteResourceMaster(Integer empNo) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		ResourceMasterEntity rme = (ResourceMasterEntity) session.get(ResourceMasterEntity.class,empNo);
		if (rme != null) {
			session.delete(rme);
		}
		else
		{
			throw new Exception("Service.RESOURCE_MASTER_NOT_FOUND");
		}
		
	}
	
	
	@Override
	public List<ResourceMaster> getResourceByProjectCode(String projectCode)throws Exception{
		
		List<ResourceMaster> resources =new ArrayList<>();
	       Session session = sessionFactory.getCurrentSession();
			
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<ResourceMasterEntity> criteriaQuery = builder
					.createQuery(ResourceMasterEntity.class);
			
			Root<ResourceMasterEntity> root = criteriaQuery.from(ResourceMasterEntity.class);
			criteriaQuery.select(root);
			
			criteriaQuery.where(builder.equal(root.get("projectCode"), projectCode));
			List<ResourceMasterEntity> resourceMasterEntityList = session.createQuery(criteriaQuery).list();
			System.out.println(resourceMasterEntityList.size());
			
			for(ResourceMasterEntity resource:resourceMasterEntityList){
				ResourceMaster resourceMaster=new ResourceMaster();
				resourceMaster.setCity(resource.getCity());
				resourceMaster.setEmpNo(resource.getEmpNo());
				resourceMaster.setInfyManager(resource.getInfyManager());
				resourceMaster.setLOC(resource.getLOC());
				resourceMaster.setPrimarySkill(resource.getPrimarySkill());
				resourceMaster.setResourceName(resource.getResourceName());
				resourceMaster.setSecondarySkill(resource.getSecondarySkill());
				resourceMaster.setVisaNumber(resource.getVisaNumber());
				resourceMaster.setVisaManager(resource.getVisaManager());
				resourceMaster.setUnit(resource.getUnit());
				resourceMaster.setProjectCode(resource.getProjectCode());
				resourceMaster.setRate(resource.getRate());
				System.out.println("abc");
				System.out.println(resource.getJobTier());
				System.out.println(resource.getRole());
				System.out.println("def");
				resourceMaster.setJobTier(resource.getJobTier());
				resourceMaster.setRole(resource.getRole());
				resources.add(resourceMaster);
				
			
			}
			return resources;
				
	}
	@Override
	public List<ResourceMaster> getResourceByVisaManager(String visaManager)throws Exception{
		
		List<ResourceMaster> resources =new ArrayList<>();
       Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ResourceMasterEntity> criteriaQuery = builder
				.createQuery(ResourceMasterEntity.class);
		
		Root<ResourceMasterEntity> root = criteriaQuery.from(ResourceMasterEntity.class);
		criteriaQuery.select(root);
		
		criteriaQuery.where(builder.equal(root.get("visaManager"), visaManager));
		List<ResourceMasterEntity> resourceMasterEntityList = session.createQuery(criteriaQuery).list();
		for(ResourceMasterEntity resource:resourceMasterEntityList){
			ResourceMaster resourceMaster=new ResourceMaster();
			resourceMaster.setCity(resource.getCity());
			resourceMaster.setEmpNo(resource.getEmpNo());
			resourceMaster.setInfyManager(resource.getInfyManager());
			resourceMaster.setLOC(resource.getLOC());
			resourceMaster.setPrimarySkill(resource.getPrimarySkill());
			resourceMaster.setResourceName(resource.getResourceName());
			resourceMaster.setSecondarySkill(resource.getSecondarySkill());
			resourceMaster.setVisaNumber(resource.getVisaNumber());
			resourceMaster.setVisaManager(resource.getVisaManager());
			resourceMaster.setUnit(resource.getUnit());
			resourceMaster.setProjectCode(resource.getProjectCode());
			resourceMaster.setRate(resource.getRate());
			resourceMaster.setJobTier(resource.getJobTier());
			resourceMaster.setRole(resource.getRole());
			resources.add(resourceMaster);
			
			
			
		}
		return resources;
		
	}
	
	
	@Override
	public List<ResourceMaster> getAllResources()throws Exception{
		
		List<ResourceMaster> resources =new ArrayList<>();
       Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ResourceMasterEntity> criteriaQuery = builder
				.createQuery(ResourceMasterEntity.class);
		
		Root<ResourceMasterEntity> root = criteriaQuery.from(ResourceMasterEntity.class);
		criteriaQuery.select(root);
		List<ResourceMasterEntity> resourceMasterEntityList = session.createQuery(criteriaQuery).list();
		for(ResourceMasterEntity resource:resourceMasterEntityList){
			ResourceMaster resourceMaster=new ResourceMaster();
			resourceMaster.setCity(resource.getCity());
			resourceMaster.setEmpNo(resource.getEmpNo());
			resourceMaster.setInfyManager(resource.getInfyManager());
			resourceMaster.setLOC(resource.getLOC());
			resourceMaster.setPrimarySkill(resource.getPrimarySkill());
			resourceMaster.setResourceName(resource.getResourceName());
			resourceMaster.setSecondarySkill(resource.getSecondarySkill());
			resourceMaster.setVisaNumber(resource.getVisaNumber());
			resourceMaster.setVisaManager(resource.getVisaManager());
			resourceMaster.setUnit(resource.getUnit());
			resourceMaster.setProjectCode(resource.getProjectCode());
			resourceMaster.setRate(resource.getRate());
			
			resourceMaster.setJobTier(resource.getJobTier());
			resourceMaster.setRole(resource.getRole());
			
			resources.add(resourceMaster);
			
			
			
		}
		return resources;
		
	}
	

}
