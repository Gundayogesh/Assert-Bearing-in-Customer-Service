package com.infy.resourcemanagement.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.resourcemanagement.entity.LoginEntity;

import com.infy.resourcemanagement.model.Login;



@Repository(value = "loginDAO")
public class LoginDAO {
	@Autowired
	SessionFactory sessionFactory;
	
	public String addUser(Login login)throws Exception{
	
			
			Session session = sessionFactory.getCurrentSession();
			LoginEntity le= new LoginEntity();
			if(login!=null)
			{
				
				le.setUserName(login.getUserName());
				le.setPassword(login.getPassword());
				le.setEmail(login.getEmail());
				login.setMessage("Added Successfully");
				return (String) session.save(le);
			}
			return null;
	}
		

public Login getuser(String userName)throws Exception{
	  
	  Login login=new Login();
		Session session = sessionFactory.getCurrentSession();
		LoginEntity loginEntity = (LoginEntity) session.get(LoginEntity.class,userName);
		if(loginEntity!=null)
		{
			login.setPassword(loginEntity.getPassword());
			login.setUserName(loginEntity.getUserName());
			login.setMessage("successfull");
		}
	  
		return login;
  }
	
	
	

	

}
