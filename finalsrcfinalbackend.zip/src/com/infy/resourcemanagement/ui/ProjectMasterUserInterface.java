package com.infy.resourcemanagement.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.infy.resourcemanagement.configuration.AppConfig;
import com.infy.resourcemanagement.entity.CostEntity;
import com.infy.resourcemanagement.entity.ResourceMasterEntity;
import com.infy.resourcemanagement.model.Cost;
import com.infy.resourcemanagement.model.ProjectMaster;
import com.infy.resourcemanagement.model.ResourceMaster;
import com.infy.resourcemanagement.service.CostService;
import com.infy.resourcemanagement.service.ProjectMasterService;
import com.infy.resourcemanagement.service.ResourceMasterService;
import com.infy.resourcemanagement.utility.ContextFactory;



public class ProjectMasterUserInterface {
	static ProjectMasterService projectMasterService = (ProjectMasterService) ContextFactory
			.getContext().getBean("projectMasterService");
	static ResourceMasterService resourceMasterService = (ResourceMasterService) ContextFactory
			.getContext().getBean("resourceMasterService");
	static CostService costService = (CostService) ContextFactory
			.getContext().getBean("costService");
	public static void main(String[] args) throws Exception {

	addAllProjectMaster();
//		 getProjectmaster();
//		addproject();
//		deleteProject();
//		updateProject();
		//getAllProjects();
		//getResourceByProjectCode();

	}
	
	private static void getResourceByProjectCode() {
		
		List<ResourceMaster> details=null;
		try{
			details=(List<ResourceMaster>) resourceMasterService.getResourceByProjectCode("VISACTAH");
			for(ResourceMaster resourceMaster:details){
			
				
				System.out.println(resourceMaster.getEmpNo());
			}
		}
		catch(Exception e)
		{
			System.out
			.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	private static void getAllProjects() {
		// TODO Auto-generated method stub
		List<ProjectMaster> details = null;
		try{
			details=projectMasterService.getAllProjects();
			for(ProjectMaster resourceMaster:details){
			
				
				System.out.println(resourceMaster.getFunctionalHead());
			}
		}
		catch(Exception e)
		{
			System.out
			.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
		
	}
	public static void getProjectmaster(){
		try {
			ProjectMaster projectMaster = projectMasterService.getProjectMaster("InfyTQ4");

			System.out.println("ProjectMaster Details");
			System.out.println("=================");
			System.out.println("ProjectMaster Name\t: " + projectMaster.getWOName());
//			System.out.println("ProjectRTN\t: " + projectMaster.getProjectRTN());
//			System.out.println("WorkOrderManage is:\t"+projectMaster.getWorkOrderManage());
//			System.out.println("ChargeWorkOrderNo is:\t"+projectMaster.getChargeWorkOrderNo());
//			System.out.println("WorkOrderValue is:\t"+projectMaster.getWorkOrderValue());
//			System.out.println("ProjectStartDate is:\t"+projectMaster.getProjectStartDate());
//			System.out.println("ProjectEndDate is:\t"+projectMaster.getProjectEndDate());
//			System.out.println("GWNNumber is:\t"+projectMaster.getGwnNumber());

		} catch (Exception e) {
			e.printStackTrace();
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("UserInterface.Project_Master_NOT_FOUND");
			}
			System.out.println("\nERROR:" + message);
		}
	}
	public static void addproject() throws Exception {

		List<ResourceMasterEntity> li=new ArrayList<>();
		
		List<ResourceMaster> liTemp=resourceMasterService.getResourceByProjectCode("VISVBCA1");
		for(ResourceMaster rme:liTemp)
		{
			ResourceMasterEntity resourceMaster=new ResourceMasterEntity();
			resourceMaster.setCity(rme.getCity());
			resourceMaster.setEmpNo(rme.getEmpNo());
			resourceMaster.setInfyManager(rme.getInfyManager());
			resourceMaster.setLOC(rme.getLOC());
			resourceMaster.setPrimarySkill(rme.getPrimarySkill());
			resourceMaster.setResourceName(rme.getResourceName());
			resourceMaster.setSecondarySkill(rme.getSecondarySkill());
			resourceMaster.setVisaManager(rme.getVisaManager());
			resourceMaster.setVisaNumber(rme.getVisaNumber());
			resourceMaster.setUnit(rme.getUnit());
			li.add(resourceMaster);
		}

		
		
		System.out.println("1");
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setProjectId("P11");
		projectMaster.setAmount(200);
		projectMaster.setClientServiceManager("jhi");
		projectMaster.setCostcenter(500);
		projectMaster.setCostType("fp");
		projectMaster.setCW("cw2222");
		projectMaster.setDateSubmitted(LocalDate.of(1993, 07, 22));
		projectMaster.setEndDate(LocalDate.of(1993, 07, 22));
		projectMaster.setFunctionalHead("yogi");
		projectMaster.setOppID(111);
		projectMaster.setPortfolio("sri");
		projectMaster.setProjectCode("444");
		projectMaster.setProjectType("aa");
		projectMaster.setRTN(444897);
		projectMaster.setStartDate(LocalDate.of(1993, 07, 22));
		projectMaster.setSVP("jiou");
		projectMaster.setVisaDM("dzsfsf");
		projectMaster.setVisaManager("zfh");
		projectMaster.setWOName("xf5g55f5");
		projectMaster.setWOStatus("fdsa");
		projectMaster.setWOVersion(2.2);
		projectMaster.setResource(li);

		try {
			
			String projectName=projectMasterService.addProjectMaster(projectMaster);

			System.out.println("\n"
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.PROJECT_MASTER_ADDED")
					+ projectName);
		} catch (Exception e) {
			 e.printStackTrace();
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}
	}
	public static void updateProject() {

		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setProjectId("P23");
		projectMaster.setAmount(200);
		projectMaster.setClientServiceManager("jhi");
		projectMaster.setCostcenter(500);
		projectMaster.setCostType("fp");
		projectMaster.setCW("cw1233");
		projectMaster.setDateSubmitted(LocalDate.of(1993, 07, 22));
		projectMaster.setEndDate(LocalDate.of(1993, 07, 22));
		projectMaster.setFunctionalHead("yogi");
		projectMaster.setOppID(111);
		projectMaster.setPortfolio("sri");
		projectMaster.setProjectCode("444");
		projectMaster.setProjectType("aa");
		projectMaster.setRTN(444);
		projectMaster.setStartDate(LocalDate.of(1993, 07, 22));
		projectMaster.setSVP("jiou");
		projectMaster.setVisaDM("dzsfsf");
		projectMaster.setVisaManager("zfh");
		projectMaster.setWOName("xf");
		projectMaster.setWOStatus("fdsa");
		projectMaster.setWOVersion(2.2);
		try {
			projectMasterService.updateProjectMaster(projectMaster);
			System.out.println("\n"
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.PROJECT_MASTER_UPDATED1")
					+projectMaster.getWOName()
					+ " "
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.PROJECT_MASTER_UPDATED2"));

		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}
	}
	public static void deleteProject() {
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setWOName("xf");

		try {
			projectMasterService.deleteProjectMaster(projectMaster.getWOName());
			System.out.println("\n"
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.PROJECT_DELETED1")
					+ " "
					+ projectMaster.getWOName()
					+ " "
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.PROJECT_DELETED2"));

		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}

	}
	
	public static void addAllProjectMaster() throws Exception
	{
		FileInputStream file=new FileInputStream(new File("D:/Intern_project_sample_date.xlsx"));
		
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		
		XSSFSheet sheet=workbook.getSheetAt(0);
		
		
		XSSFRow row;
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		for(int i=1;i<=sheet.getLastRowNum();i++)
		{
			row=(XSSFRow) sheet.getRow(i);
			String projectId;
			if(row.getCell(0)==null) 
				projectId="null";
			else
				projectId=row.getCell(0).toString();
			
			String CWNumber;
			if(row.getCell(1)==null) 
				CWNumber="null";
			else
				CWNumber=row.getCell(1).toString();
			
			Integer rtnNumber;
			if(row.getCell(2)==null)
				rtnNumber=0;
			else
			{
				String st=row.getCell(2).toString();
				System.out.println(st);
				Double d=Double.parseDouble(st);
				rtnNumber=d.intValue();
			}
			
			String WOName;
			if(row.getCell(3)==null) 
				WOName="null";
			else
				WOName=row.getCell(3).toString();
			
			String visaManager;
			if(row.getCell(4)==null) 
				visaManager="null";
			else
				visaManager=row.getCell(4).toString();
			
			String visaDm;
			if(row.getCell(5)==null) 
				visaDm="null";
			else
				visaDm=row.getCell(5).toString();
			
			String functinalhead;
			if(row.getCell(6)==null) 
				functinalhead="null";
			else
				functinalhead=row.getCell(6).toString();
			
			String svp;
			if(row.getCell(7)==null) 
				svp="null";
			else
				svp=row.getCell(7).toString();
			
			Integer costCenter;
			if(row.getCell(8)==null)
				costCenter=0;
			else
			{
				String st=row.getCell(8).toString();
				System.out.println(st);
				Double d=Double.parseDouble(st);
				costCenter=d.intValue();
			}
			
			Integer amount;
			if(row.getCell(9)==null)
				amount=0;
			else
			{
				String st=row.getCell(9).toString();
				System.out.println(st);
				Double d=Double.parseDouble(st);
				amount=d.intValue();
			}
			
			String costType;
			if(row.getCell(10)==null) 
				costType="null";
			else
				costType=row.getCell(10).toString();
			
			String projectType;
			if(row.getCell(11)==null) 
				projectType="null";
			else
				projectType=row.getCell(11).toString();
			
			LocalDate startDate;
			if(row.getCell(12)==null) 
				startDate=null;
			else
				startDate=LocalDate.parse(row.getCell(12).toString(), formatter);
			
			
			LocalDate endDate;
			if(row.getCell(13)==null) 
				endDate=null;
			else
				endDate=LocalDate.parse(row.getCell(13).toString(), formatter);
			
			LocalDate dateSubmitted;
			if(row.getCell(14)==null) 
				dateSubmitted=null;
			else
				dateSubmitted=LocalDate.parse(row.getCell(14).toString(), formatter);
			
			String WOStatus;
			if(row.getCell(15)==null) 
				WOStatus="null";
			else
				WOStatus=row.getCell(15).toString();
			
			String clientServiceManager;
			if(row.getCell(16)==null) 
				clientServiceManager="null";
			else
				clientServiceManager=row.getCell(16).toString();
			
			String portfolio;
			if(row.getCell(17)==null) 
				portfolio="null";
			else
				portfolio=row.getCell(17).toString();
			
			Integer oppId;
			if(row.getCell(18)==null)
				oppId=0;
			else
			{
				String st=row.getCell(18).toString();
				System.out.println(st);
				Double d=Double.parseDouble(st);
				oppId=d.intValue();
			}
			
			Double woVesrsion;
			if(row.getCell(19)==null)
				woVesrsion=0.0;
			else
			{
				String st=row.getCell(19).toString();
				System.out.println(st);
				woVesrsion=Double.parseDouble(st);
			}
			
			String projectCode;
			if(row.getCell(20)==null) 
				projectCode="null";
			else
				projectCode=row.getCell(20).toString();
			
			
			List<ResourceMasterEntity> li=new ArrayList<>();
			
			List<ResourceMaster> liTemp=resourceMasterService.getResourceByProjectCode(projectCode);
			System.out.println("xszdjklhs");
			System.out.println(projectCode);
			System.out.println(liTemp.size());
			System.out.println("asd.;fjklsdfil;j");
			for(ResourceMaster rme:liTemp)
			{
				ResourceMasterEntity resourceMaster=new ResourceMasterEntity();
				resourceMaster.setCity(rme.getCity());
				resourceMaster.setEmpNo(rme.getEmpNo());
				resourceMaster.setInfyManager(rme.getInfyManager());
				resourceMaster.setLOC(rme.getLOC());
				resourceMaster.setPrimarySkill(rme.getPrimarySkill());
				resourceMaster.setResourceName(rme.getResourceName());
				resourceMaster.setSecondarySkill(rme.getSecondarySkill());
				resourceMaster.setVisaManager(rme.getVisaManager());
				resourceMaster.setVisaNumber(rme.getVisaNumber());
				resourceMaster.setUnit(rme.getUnit());
				resourceMaster.setProjectCode(projectCode);
				resourceMaster.setRate(rme.getRate());
				resourceMaster.setRole(rme.getRole());
				resourceMaster.setJobTier(rme.getJobTier());
				
				li.add(resourceMaster);
			}
			
			System.out.println(CWNumber);
			System.out.println(rtnNumber);
			System.out.println(svp);
			System.out.println(WOStatus);
			System.out.println(woVesrsion);
			System.out.println(amount);
			System.out.println(clientServiceManager);
			System.out.println(costType);
			System.out.println(costCenter);
			System.out.println(dateSubmitted);
			System.out.println(endDate);
			System.out.println(functinalhead);
			System.out.println(oppId);
			System.out.println(portfolio);
			System.out.println(projectCode);
			System.out.println(projectType);
			System.out.println(startDate);
			System.out.println(visaDm);
			System.out.println(visaManager);
			System.out.println(WOName);
			
			ProjectMaster pm=new ProjectMaster();
			pm.setProjectId(projectId);
			pm.setAmount(amount);
			pm.setClientServiceManager(clientServiceManager);
			pm.setCostcenter(costCenter);
			pm.setCostType(costType);
			pm.setCW(CWNumber);
			pm.setDateSubmitted(dateSubmitted);
			pm.setEndDate(endDate);
			pm.setFunctionalHead(functinalhead);
			pm.setOppID(oppId);
			pm.setPortfolio(portfolio);
			pm.setProjectCode(projectCode);
			pm.setProjectType(projectType);
			pm.setResource(li);
			pm.setRTN(rtnNumber);
			pm.setStartDate(startDate);
			pm.setSVP(svp);
			pm.setVisaDM(visaDm);
			pm.setVisaManager(visaManager);
			pm.setWOName(WOName);
			pm.setWOStatus(WOStatus);
			pm.setWOVersion(woVesrsion);
			System.out.println("yogeshhhhhh");
			System.out.println(li.size());
			
			try {
				
				String projectName=projectMasterService.addProjectMaster(pm);

				System.out.println("\n"
						+ AppConfig.PROPERTIES
								.getProperty("UserInterface.PROJECT_MASTER_ADDED")
						+ projectName);
			} catch (Exception e) {
				 e.printStackTrace();
				String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
				if (message == null) {
					message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
				}
				System.out.println("\nERROR:" + message);
			
			
			}
			
			
			List<ResourceMaster> list=resourceMasterService.getResourceByProjectCode(projectCode);
			System.out.println("a.fhaspidl/fbnlxcvsdvfsdgftrsdvfdgrsetgjsdhbvgklgf"+projectCode);
			for(ResourceMaster r:list)
			{
				Cost c=new Cost();
				c.setStatus(WOStatus);
				c.setProjectCode(projectCode);
				c.setInfyManager(clientServiceManager);
				c.setProjectId(projectId);
				c.setWoName(WOName);
				c.setVisaManager(visaManager);
				c.setEmpNo(r.getEmpNo());
				c.setResourceName(r.getResourceName());
				c.setUnit(r.getUnit());
				c.setLOC(r.getLOC());
				System.out.println("xyz");
				System.out.println(r.getRole());
				System.out.println(r.getJobTier());
				System.out.println("pqr");
				c.setRole(r.getRole());
				c.setJobTier(r.getJobTier());
				c.setRate(r.getRate());
				c.setJan(0d);
				c.setFeb(0d);
				c.setMar(0d);
				c.setApr(0d);
				c.setMay(0d);
				c.setJun(0d);
				c.setJul(0d);
				c.setAug(0d);
				c.setSep(0d);
				c.setOct(0d);
				c.setNov(0d);
				c.setDec(0d);
				c.setAmountTillDate(0d);
				costService.addCostEntity(c);
			}
			
		file.close();
		}
	}
}

