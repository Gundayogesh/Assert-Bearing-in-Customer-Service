package com.infy.resourcemanagement.ui;

import com.infy.resourcemanagement.service.Loginservice;
import com.infy.resourcemanagement.utility.ContextFactory;

public class loginUi {
	static Loginservice projectMasterService = (Loginservice) ContextFactory
			.getContext().getBean("loginservice");
	
	public static void main(String[] args) throws Exception {

//		addUser();
//		getUser();

	}

	private static void addUser() {
		
		
		
	}
}
