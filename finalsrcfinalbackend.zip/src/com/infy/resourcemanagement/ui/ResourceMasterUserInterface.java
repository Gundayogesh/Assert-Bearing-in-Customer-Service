package com.infy.resourcemanagement.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

//import org.apache.poi.xssf.usermodel.XSSFRow;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;






import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.infy.resourcemanagement.configuration.AppConfig;
import com.infy.resourcemanagement.model.Cost;
import com.infy.resourcemanagement.model.ResourceMaster;
import com.infy.resourcemanagement.service.ResourceMasterService;
import com.infy.resourcemanagement.utility.ContextFactory;

public class ResourceMasterUserInterface {
	static ResourceMasterService resourceMasterService = (ResourceMasterService) ContextFactory
			.getContext().getBean("resourceMasterService");
	public static void main(String[] args) throws Exception {

		addAllResourceMaster();
		//getResource();
		//getAllResources();
//		getResourceByVisaManager();
//		addResource();
//		deleteResource();
//		updateResource();
		//getResourceByProjectId();
	}
	
	public static void getResourceByProjectId() {
		
	}
	private static void getResourceByVisaManager() {
		// TODO Auto-generated method stub
		List<ResourceMaster> details = null;
		try{
			
			details=resourceMasterService.getResourceByVisaManager("sate");
			for(ResourceMaster resourceMaster:details){
				System.out.println("ResourceMaster Details");
				System.out.println("=================");
				System.out.println("ResourceMaster Name\t: " + resourceMaster.getResourceName() );
				System.out.println("Employee Number\t: " + resourceMaster.getEmpNo());
				System.out.println("visa number\t:"+resourceMaster.getVisaNumber());
				System.out.println("unit\t:"+resourceMaster.getUnit());
				System.out.println("LOC\t:"+resourceMaster.getLOC());
				System.out.println("city\t:"+resourceMaster.getCity());
				System.out.println("primarySkill\t:"+resourceMaster.getPrimarySkill());
				System.out.println("secondarySkill\t:"+resourceMaster.getSecondarySkill());
				System.out.println("visaManager\t:"+resourceMaster.getVisaManager());
				System.out.println("infyManager\t:"+resourceMaster.getInfyManager());
			}
			
			
		}
		catch(Exception e)
		{
			System.out
			.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
		
	}
	private static void getAllResources() {
		// TODO Auto-generated method stub
		List<ResourceMaster> details = null;
		try{
			details=resourceMasterService.getallResources();
			for(ResourceMaster resourceMaster:details){
				System.out.println("ResourceMaster Details");
				System.out.println("=================");
				System.out.println("ResourceMaster Name\t: " + resourceMaster.getResourceName() );
				System.out.println("Employee Number\t: " + resourceMaster.getEmpNo());
				System.out.println("visa number\t:"+resourceMaster.getVisaNumber());
				System.out.println("unit\t:"+resourceMaster.getUnit());
				System.out.println("LOC\t:"+resourceMaster.getLOC());
				System.out.println("city\t:"+resourceMaster.getCity());
				System.out.println("primarySkill\t:"+resourceMaster.getPrimarySkill());
				System.out.println("secondarySkill\t:"+resourceMaster.getSecondarySkill());
				System.out.println("visaManager\t:"+resourceMaster.getVisaManager());
				System.out.println("infyManager\t:"+resourceMaster.getInfyManager());
			}
		}
		catch(Exception e)
		{
			System.out
			.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
		
	}
	public static void getResource(){
		try {
			ResourceMaster resourceMaster = resourceMasterService.getResourceMaster(5001);

			System.out.println("ResourceMaster Details");
			System.out.println("=================");
			System.out.println("ResourceMaster Name\t: " + resourceMaster.getResourceName() );
			System.out.println("Employee Number\t: " + resourceMaster.getEmpNo());
			System.out.println("visa number\t:"+resourceMaster.getVisaNumber());
			System.out.println("unit\t:"+resourceMaster.getUnit());
			System.out.println("LOC\t:"+resourceMaster.getLOC());
			System.out.println("city\t:"+resourceMaster.getCity());
			System.out.println("primarySkill\t:"+resourceMaster.getPrimarySkill());
			System.out.println("secondarySkill\t:"+resourceMaster.getSecondarySkill());
			

		} catch (Exception e) {
			e.printStackTrace();
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("UserInterface.RESOURCE_MASTER_NOT_FOUND");
			}
			System.out.println("\nERROR:" + message);
		}
	}
	public static void addResource(){

		System.out.println("1");
		ResourceMaster resourceMaster = new ResourceMaster();
		
		resourceMaster.setCity("hyd");
		resourceMaster.setEmpNo(1055);
		resourceMaster.setInfyManager("sri");
		resourceMaster.setLOC("hii");
		resourceMaster.setPrimarySkill("cricket");
		resourceMaster.setResourceName("yogi");
		resourceMaster.setSecondarySkill("trav");
		resourceMaster.setVisaManager("zfh");
		resourceMaster.setUnit("jee");
		resourceMaster.setVisaNumber(4444);
		
		
		try {
			
			Integer empNo=resourceMasterService.addResourceMaster(resourceMaster);

			System.out.println("\n"
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.RESOURCE_MASTER_ADDED")
					+ empNo);
		} catch (Exception e) {
			// e.printStackTrace();
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}
	}
	public static void updateResource(){


		ResourceMaster resourceMaster = new ResourceMaster();
		
		resourceMaster.setCity("ban");
		resourceMaster.setEmpNo(1033);
		resourceMaster.setInfyManager("sri");
		resourceMaster.setLOC("hii");
		resourceMaster.setPrimarySkill("Foot");
		resourceMaster.setResourceName("yogi");
		resourceMaster.setSecondarySkill("trav");
		resourceMaster.setUnit("jee");
		resourceMaster.setVisaManager("satasdade");
		resourceMaster.setVisaNumber(555);
		
		try {
			
			resourceMasterService.updateResourceMaster(resourceMaster);

			System.out.println("\n"
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.RESOURCE_MASTER_UPDATED1")
					+resourceMaster.getEmpNo()
					+ " "
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.RESOURCE_MASTER_UPDATED2"));
		} catch (Exception e) {
			// e.printStackTrace();
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}
}
	public static void deleteResource() {
		ResourceMaster resourceMaster = new ResourceMaster();
		resourceMaster.setEmpNo(1000);

		try {
			resourceMasterService.deleteResourceMaster(resourceMaster.getEmpNo());
			System.out.println("\n"
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.RESOURCE_DELETED1")
					+ " "
					+ resourceMaster.getEmpNo()
					+ " "
					+ AppConfig.PROPERTIES
							.getProperty("UserInterface.RESOURCE_DELETED2"));

		} catch (Exception e) {
			String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
			if (message == null) {
				message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}
	
	}

	public static void addAllResourceMaster() throws IOException{
		
		
		FileInputStream file=new FileInputStream(new File("D:/Intern_project_sample_date.xlsx"));
		
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		
		XSSFSheet sheet=workbook.getSheetAt(2);
		
		
		XSSFRow row;
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		for(int i=1;i<sheet.getLastRowNum();i++)
		{
			row=(XSSFRow) sheet.getRow(i);
			
			Integer empNo;
			if(row.getCell(0)==null)
				empNo=0;
			else
			{
				String st=row.getCell(0).toString();
				System.out.println(st);
				Double d=Double.parseDouble(st);
				empNo=d.intValue();
			}
			
			Integer visaNumber;
			if(row.getCell(1)==null)
				visaNumber=0;
			else
			{
				String st=row.getCell(1).toString();
				System.out.println(st);
				Double d=Double.parseDouble(st);
				visaNumber=d.intValue();
			}
			
			String resourceName;
			if(row.getCell(2)==null) 
				resourceName="null";
			else
				resourceName=row.getCell(2).toString();
			
			
			String unit;
			if(row.getCell(3)==null) 
				unit="null";
			else
				unit=row.getCell(3).toString();
			
			String loc;
			if(row.getCell(4)==null) 
				loc="null";
			else
				loc=row.getCell(4).toString();
			
			String city;
			if(row.getCell(5)==null) 
				city="null";
			else
				city=row.getCell(5).toString();
			
			String primarySkill;
			if(row.getCell(6)==null) 
				primarySkill="null";
			else
				primarySkill=row.getCell(6).toString();
			
			String secondarySkill;
			if(row.getCell(7)==null) 
				secondarySkill="null";
			else
				secondarySkill=row.getCell(7).toString();
			
			String clientManager;
			if(row.getCell(8)==null) 
				clientManager="null";
			else
				clientManager=row.getCell(8).toString();
			
			
			String infyManager;
			if(row.getCell(9)==null) 
				infyManager="null";
			else
				infyManager=row.getCell(9).toString();
			
			String projectCode;
			if(row.getCell(10)==null) 
				projectCode="null";
			else
				projectCode=row.getCell(10).toString();
			
			Double rate;
			if(row.getCell(11)==null)
				rate=0.0;
			else
			{
				String st=row.getCell(11).toString();
				System.out.println(st);
				rate=Double.parseDouble(st);
			}
			
	        String role;
			if(row.getCell(12)==null)
				role="null";
			else
			{
				role=row.getCell(12).toString();
				
			}
			  String jobTier = null;
				if(row.getCell(13)==null)
				{
					jobTier="null";
				}
				else
				{
					jobTier=row.getCell(13).toString();
					
				}
			
			System.out.println(projectCode);
			
			System.out.print(empNo);
			System.out.print(visaNumber);
			System.out.println(resourceName);
			System.out.print(unit);
			System.out.print(loc);
			System.out.println(city);
			System.out.println(primarySkill);
			System.out.println(secondarySkill);
			System.out.print(clientManager);
			System.out.print(infyManager);
			
			ResourceMaster rm=new ResourceMaster();
			rm.setCity(city);
			rm.setEmpNo(empNo);
			rm.setInfyManager(infyManager);
			rm.setLOC(loc);
			rm.setPrimarySkill(primarySkill);
			rm.setResourceName(resourceName);
			rm.setSecondarySkill(secondarySkill);
			rm.setUnit(unit);
			rm.setVisaManager(clientManager);
			rm.setVisaNumber(visaNumber);
			rm.setProjectCode(projectCode);
			rm.setRate(rate);
			rm.setRole(role);
			rm.setJobTier(jobTier);
			try {
				
				Integer empNo1=resourceMasterService.addResourceMaster(rm);

				System.out.println("\n"
						+ AppConfig.PROPERTIES
								.getProperty("UserInterface.RESOURCE_MASTER_ADDED")
						+ empNo1);
			} catch (Exception e) {
				// e.printStackTrace();
				String message = AppConfig.PROPERTIES.getProperty(e.getMessage());
				if (message == null) {
					message = AppConfig.PROPERTIES.getProperty("General.EXCEPTION");
				}
				System.out.println("\nERROR:" + message);
			}
			
			
			
		}
		file.close();
	}
}