package com.infy.resourcemanagement.ui;

import java.util.List;

import com.infy.resourcemanagement.model.Cost;
import com.infy.resourcemanagement.model.Graph;
import com.infy.resourcemanagement.service.CostService;
import com.infy.resourcemanagement.utility.ContextFactory;

public class CostUI {
	
	static CostService costService = (CostService) ContextFactory
			.getContext().getBean("costService");
	
	public static void main(String[] args) throws Exception {
		
		
		//addCostEntity();
//		amountTillDate();
//		getAllCostEntity();
		getAllGraphDetaila();
	}

	private static void getAllCostEntity() throws Exception {
		// TODO Auto-generated method stub
		List<Cost> li=costService.getALLCostEntity();
		System.out.println(li.size());
	}

	private static void amountTillDate() {
		// TODO Auto-generated method stub
//		Cost c=new Cost();
//		c.setWOName("VBC");
//		c.setEmpNo(12345);
//		
//		try{
//			
//		    System.out.println(costService.amountTillDateService(c));
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
		
		
	}

	private static void addCostEntity() {
		// TODO Auto-generated method stub
		
//		Cost c=new Cost();
//		c.setWOName("VBC");
//		c.setEmpNo(12345);
//		c.setMonth("NOV");
//		c.setNoOfHours(20d);
//		
//		try {
//			Cost name=costService.addCostEntity(c);
//			System.out.println(name);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		
	}
	private static void getAllGraphDetaila() throws Exception
	{
		List<Graph> li=costService.getAllgraphdetails();
		System.out.println(li.size());
	}

}
