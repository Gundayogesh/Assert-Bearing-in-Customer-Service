package com.infy.resourcemanagement.api;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.infy.resourcemanagement.service.FileBean;
import com.infy.resourcemanagement.service.importService;

@CrossOrigin
@RestController
@RequestMapping("FileController")
public class FileController {
//	@RequestMapping(method = RequestMethod.POST ,value="upload")
//	public String upload(FileBean uploadItem) {
//	    importService.import1(uploadItem);
//
//	    return "import/importDone";
//	}
	
	
//	@ResponseStatus()
//	@RequestMapping(value = {"/download/excel-report"},method = RequestMethod.GET)
//	public HttpEntity<byte[]> downloadExcelReport() {
//	 
//	    /** assume that below line gives you file content in byte array **/
//	    byte[] excelContent = getReportContent();
//	    // prepare response
//	    HttpHeaders header = new HttpHeaders();
//	    header.setContentType(new MediaType("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
//	    header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Createavvavaybabu.xls");
//	    header.setContentLength(excelContent.length);
//	 
//	    return new HttpEntity<byte[]>(excelContent, header);
//	}
//
//	private byte[] getReportContent() {
//		
//		XSSFWorkbook workbook = new XSSFWorkbook();
//	    XSSFSheet sheet = workbook.createSheet("Sheet 1");
//	
//	    Row row = sheet.createRow(1);
//	    Cell cell = row.createCell(cellnum++);
//	    cell.setCellValue((String) obj);
//	    ByteArrayOutputStream bos = new ByteArrayOutputStream();
//	    try {
//	        workbook.write(bos);
//	    } catch (IOException e) {
//	    } finally {
//	        try {
//	            bos.close();
//	            workbook.close();
//	        } catch (IOException e) {
//	        }
//	    }
//	    byte[] bytes = bos.toByteArray();
//	}

	
}
