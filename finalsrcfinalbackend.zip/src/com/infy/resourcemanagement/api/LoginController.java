package com.infy.resourcemanagement.api;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.resourcemanagement.model.Login;
import com.infy.resourcemanagement.model.ResourceMaster;
import com.infy.resourcemanagement.service.Loginservice;
import com.infy.resourcemanagement.service.ResourceMasterService;
import com.infy.resourcemanagement.service.ResourceMasterserviceImpl;
import com.infy.resourcemanagement.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("LoginApi")
public class LoginController {

	@RequestMapping(method = RequestMethod.POST, value = "getUser")
	public ResponseEntity<Login> getUser(@RequestBody Login rm) {
		Loginservice loginservice = (Loginservice) ContextFactory.getContext().getBean(Loginservice.class);

		Login login = new Login();
		try {

			login = loginservice.getUser(rm.getUserName());
			return new ResponseEntity<Login>(login,HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext().getEnvironment();
			login.setMessage("User Already Exists");
			return new ResponseEntity<Login>(login,HttpStatus.OK);
		}
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "adduser")
	public ResponseEntity<Login> addUser(@RequestBody Login loginToAdd) {
		Loginservice loginservice = (Loginservice) ContextFactory.getContext().getBean(Loginservice.class);
		try {
			System.out.println("add res");
			String username = loginservice.addUser(loginToAdd);
			loginToAdd.setUserName(username);
			return new ResponseEntity<Login>(loginToAdd,HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext().getEnvironment();
			loginToAdd.setMessage(environment.getProperty(e.getMessage()));
			return new ResponseEntity<Login>(loginToAdd,HttpStatus.BAD_REQUEST);
		}
	}
}
