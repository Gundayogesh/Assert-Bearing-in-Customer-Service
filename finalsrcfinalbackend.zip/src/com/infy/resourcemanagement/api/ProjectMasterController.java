package com.infy.resourcemanagement.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;




import com.infy.resourcemanagement.model.ProjectMaster;

import com.infy.resourcemanagement.service.ProjectMasterService;
import com.infy.resourcemanagement.service.ProjectMasterServiceImpl;

import com.infy.resourcemanagement.utility.ContextFactory;

@CrossOrigin
@RestController
@RequestMapping("ProjectMasterApi")
public class ProjectMasterController {
       
       @RequestMapping(method=RequestMethod.POST, value="getProjectMaster")
       public ResponseEntity<ProjectMaster> getProjectMaster(@RequestBody ProjectMaster pm){
           ProjectMasterService projectMasterService = (ProjectMasterService) ContextFactory.getContext().getBean(ProjectMasterServiceImpl.class);

              ProjectMaster projectMaster=new ProjectMaster();
              try {
                     System.out.println(pm.getWOName());
                     projectMaster=projectMasterService.getProjectMaster(pm.getWOName());
                     return new ResponseEntity<ProjectMaster>(projectMaster,HttpStatus.OK);
              } catch (Exception e) {
                     Environment environment = ContextFactory.getContext().getEnvironment();
                     projectMaster.setMessage(environment.getProperty(e.getMessage()));
                     return new ResponseEntity<ProjectMaster>(projectMaster,HttpStatus.BAD_REQUEST);
              }
       }

       @RequestMapping(method=RequestMethod.POST, value="updateProjectMaster/{projectName}")
       public ResponseEntity<ProjectMaster> updateProjectMaster(@PathVariable("projectName") String projectName, @RequestBody ProjectMaster projectMasterToUpdate){
           ProjectMasterService projectMasterService = (ProjectMasterService) ContextFactory.getContext().getBean(ProjectMasterService.class);

              ProjectMaster projectMaster=new ProjectMaster();
              try {
            	  System.out.println(projectMasterToUpdate.getWOName());
                     if(projectMasterToUpdate == null || (!projectName.equals(projectMasterToUpdate.getWOName()))){
                           return new ResponseEntity<ProjectMaster>(projectMaster,HttpStatus.BAD_REQUEST);
                     }

                     projectMasterService.updateProjectMaster(projectMasterToUpdate);
                     projectMaster=projectMasterService.getProjectMaster(projectMasterToUpdate.getWOName());
                     return new ResponseEntity<ProjectMaster>(projectMaster,HttpStatus.OK);
              } catch (Exception e) {
                     Environment environment = ContextFactory.getContext().getEnvironment();
                     projectMaster.setMessage(environment.getProperty(e.getMessage()));
                     return new ResponseEntity<ProjectMaster>(projectMaster,HttpStatus.BAD_REQUEST);
              }
       }
       
       @RequestMapping(method=RequestMethod.POST, value="addProjectMaster")
       public ResponseEntity<ProjectMaster> addProjectMaster(@RequestBody ProjectMaster projectMasterToAdd){
           ProjectMasterService projectMasterService = (ProjectMasterService) ContextFactory.getContext().getBean(ProjectMasterService.class);

              try {
                     
                     String WOName= projectMasterService.addProjectMaster(projectMasterToAdd);
                     projectMasterToAdd.setWOName(WOName);
                     return new ResponseEntity<ProjectMaster>(projectMasterToAdd,HttpStatus.OK);
              } catch (Exception e) {
                     Environment environment = ContextFactory.getContext().getEnvironment();
                     projectMasterToAdd.setMessage(environment.getProperty(e.getMessage()));
                     return new ResponseEntity<ProjectMaster>(projectMasterToAdd,HttpStatus.BAD_REQUEST);
              }
       }
       
       @RequestMapping(method=RequestMethod.POST, value="deleteProjectMaster")
       public ResponseEntity<String> deleteProjectmaster(@RequestBody ProjectMaster pm)
       {
           ProjectMasterService projectMasterService = (ProjectMasterService) ContextFactory.getContext().getBean(ProjectMasterService.class);
    	   ProjectMaster projectMaster=new ProjectMaster();
           try {
                  
                  projectMasterService.deleteProjectMaster(pm.getWOName());
                  return new ResponseEntity<String>("Project Master with projectName:"+pm.getWOName()+" deleted sucessfully",HttpStatus.OK);
           } catch (Exception e) {
                  Environment environment = ContextFactory.getContext().getEnvironment();
                  projectMaster.setMessage(environment.getProperty(e.getMessage()));
                  return new ResponseEntity<String>("Project Master with projectName:"+pm.getWOName()+" not found",HttpStatus.BAD_REQUEST);
           }
       }
       
   	@RequestMapping(method=RequestMethod.GET, value="getAllProjects")
    public ResponseEntity<List<ProjectMaster>> getAllProjects(){
   		ProjectMasterService projectMasterService = (ProjectMasterService) ContextFactory.getContext().getBean(ProjectMasterService.class);

		List<ProjectMaster> projects=new ArrayList<>();
           try {
                  
        	   projects=projectMasterService.getAllProjects();
        	   return new ResponseEntity<List<ProjectMaster>>(projects,HttpStatus.OK);
           } catch (Exception e) {
                  Environment environment = ContextFactory.getContext().getEnvironment();
                  
                  return new ResponseEntity<List<ProjectMaster>>(projects,HttpStatus.OK);
           }
    }
       
}