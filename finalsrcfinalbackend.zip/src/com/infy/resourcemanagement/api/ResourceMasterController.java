package com.infy.resourcemanagement.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.resourcemanagement.model.ProjectMaster;
import com.infy.resourcemanagement.model.ResourceMaster;
import com.infy.resourcemanagement.service.CostService;
import com.infy.resourcemanagement.service.ProjectMasterService;
import com.infy.resourcemanagement.service.ResourceMasterService;
import com.infy.resourcemanagement.service.ResourceMasterserviceImpl;
import com.infy.resourcemanagement.utility.ContextFactory;

@CrossOrigin
@RestController
@RequestMapping("ResourceMasterApi")
public class ResourceMasterController {

	@RequestMapping(method = RequestMethod.POST, value = "getResourceMaster")
	public ResponseEntity<ResourceMaster> getResourceMaster(
			@RequestBody ResourceMaster rm) {
		ResourceMasterService resourceMasterService = (ResourceMasterService) ContextFactory
				.getContext().getBean(ResourceMasterserviceImpl.class);

		ResourceMaster resourceMaster = new ResourceMaster();
		try {

			resourceMaster = resourceMasterService.getResourceMaster(rm
					.getEmpNo());
			return new ResponseEntity<ResourceMaster>(resourceMaster,
					HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext()
					.getEnvironment();
			resourceMaster.setMessage(environment.getProperty(e.getMessage()));
			return new ResponseEntity<ResourceMaster>(resourceMaster,
					HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "getAllResources")
	public ResponseEntity<List<ResourceMaster>> getAllResources() {
		ResourceMasterService resourceMasterService = (ResourceMasterService) ContextFactory
				.getContext().getBean(ResourceMasterserviceImpl.class);

		List<ResourceMaster> resources = new ArrayList<>();
		try {

			resources = resourceMasterService.getallResources();
			return new ResponseEntity<List<ResourceMaster>>(resources,
					HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext()
					.getEnvironment();

			return new ResponseEntity<List<ResourceMaster>>(resources,
					HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(method = RequestMethod.POST, value = "getResourceByProjectCode/{visaManager}")
	public ResponseEntity<List<ResourceMaster>> getResourceByProjectCode(
			@PathVariable("visaManager") String visaManager) {
		ResourceMasterService resourceMasterService = (ResourceMasterService) ContextFactory
				.getContext().getBean(ResourceMasterserviceImpl.class);

		List<ResourceMaster> resources = new ArrayList<>();
		try {

			resources = resourceMasterService.getResourceByProjectCode(visaManager);
			return new ResponseEntity<List<ResourceMaster>>(resources,
					HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext()
					.getEnvironment();

			return new ResponseEntity<List<ResourceMaster>>(resources,
					HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(method = RequestMethod.POST, value = "updateResourceMaster/{empNo}")
	public ResponseEntity<ResourceMaster> updateResourceMaster(
			@PathVariable("empNo") Integer empNo,
			@RequestBody ResourceMaster resourceMasterToUpdate) {
		ResourceMasterService resourceMasterService = (ResourceMasterService) ContextFactory
				.getContext().getBean(ResourceMasterserviceImpl.class);

		ResourceMaster resourceMaster = new ResourceMaster();
		try {
			System.out.println(resourceMasterToUpdate.getEmpNo());
			if (resourceMasterToUpdate == null
					|| (!empNo.equals(resourceMasterToUpdate.getEmpNo()))) {
				return new ResponseEntity<ResourceMaster>(resourceMaster,
						HttpStatus.BAD_REQUEST);
			}
			resourceMasterService.updateResourceMaster(resourceMasterToUpdate);
			resourceMaster = resourceMasterService
					.getResourceMaster(resourceMasterToUpdate.getEmpNo());
			return new ResponseEntity<ResourceMaster>(resourceMaster,
					HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext()
					.getEnvironment();
			resourceMaster.setMessage(environment.getProperty(e.getMessage()));
			return new ResponseEntity<ResourceMaster>(resourceMaster,
					HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(method = RequestMethod.POST, value = "addResourceMaster")
	public ResponseEntity<ResourceMaster> addResourceMaster(
			@RequestBody ResourceMaster resourceMasterToAdd) {
		ResourceMasterService resourceMasterService = (ResourceMasterService) ContextFactory
				.getContext().getBean(ResourceMasterserviceImpl.class);
		CostService costService = (CostService) ContextFactory.getContext().getBean(CostService.class);
		try {
			System.out.println("add res");
			Integer empNo = resourceMasterService
					.addResourceMaster(resourceMasterToAdd);
			costService.addTimesheetForNewResource(resourceMasterToAdd);
			resourceMasterToAdd.setEmpNo(empNo);
			return new ResponseEntity<ResourceMaster>(resourceMasterToAdd,
					HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext()
					.getEnvironment();
			resourceMasterToAdd.setMessage(environment.getProperty(e
					.getMessage()));
			return new ResponseEntity<ResourceMaster>(resourceMasterToAdd,
					HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(method = RequestMethod.POST, value = "deleteResourceMaster")
	public ResponseEntity<String> deleteResourcemaster(
			@RequestBody ResourceMaster rm) {
		ResourceMasterService resourceMasterService = (ResourceMasterService) ContextFactory
				.getContext().getBean(ResourceMasterserviceImpl.class);
		ResourceMaster resourceMaster = new ResourceMaster();
		try {

			resourceMasterService.deleteResourceMaster(rm.getEmpNo());
			;
			return new ResponseEntity<String>("Resource Master with empNo:"
					+ rm.getEmpNo() + " deleted sucessfully", HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext()
					.getEnvironment();
			resourceMaster.setMessage(environment.getProperty(e.getMessage()));
			return new ResponseEntity<String>("Resource Master with empNo:"
					+ rm.getEmpNo() + " not found", HttpStatus.BAD_REQUEST);
		}
	}
}
