package com.infy.resourcemanagement.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.resourcemanagement.model.Cost;
import com.infy.resourcemanagement.model.Graph;
import com.infy.resourcemanagement.model.Login;
import com.infy.resourcemanagement.model.ResourceMaster;
import com.infy.resourcemanagement.service.CostService;
import com.infy.resourcemanagement.service.Loginservice;
import com.infy.resourcemanagement.service.ResourceMasterService;
import com.infy.resourcemanagement.service.ResourceMasterserviceImpl;
import com.infy.resourcemanagement.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("costApi")
public class CostController {
	
//	@RequestMapping(method = RequestMethod.POST, value = "addCost")
//	public ResponseEntity<Cost> addCost(@RequestBody Cost costToAdd) {
//		CostService costService = (CostService) ContextFactory.getContext().getBean(CostService.class);
//		try {
//			System.out.println("add res");
//			Cost woName = costService.addCostEntity(costToAdd);
//			
//			return new ResponseEntity<Cost>(costToAdd,HttpStatus.OK);
//		} catch (Exception e) {
//			Environment environment = ContextFactory.getContext().getEnvironment();
//			costToAdd.setMessage(environment.getProperty(e.getMessage()));
//			return new ResponseEntity<Cost>(costToAdd,HttpStatus.BAD_REQUEST);
//		}
//	}

	@RequestMapping(method = RequestMethod.GET, value = "getAllCostEntity")
	public ResponseEntity<List<Cost>> getAllCostEntity() {
		CostService costService = (CostService) ContextFactory.getContext().getBean(CostService.class);

		List<Cost> resources = new ArrayList<>();
		try {

			resources = costService.getALLCostEntity();
			return new ResponseEntity<List<Cost>>(resources,
					HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext()
					.getEnvironment();

			return new ResponseEntity<List<Cost>>(resources,
					HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "updateCostEntity")
	public ResponseEntity<List<Cost>> updateCostEntity(@RequestBody List<Cost> costList) {
		CostService costService = (CostService) ContextFactory.getContext().getBean(CostService.class);
		Cost c=new Cost();
		List<Cost> returnObjList = new ArrayList<>();
		List<Cost> resources = new ArrayList<>();
		try {

			 costService.updateTimeSheet(costList);  
			 c.setMessage("Successfully Updated");
			 returnObjList.add(c);
			return new ResponseEntity<List<Cost>>(returnObjList,HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext()
					.getEnvironment();
				c.setMessage("Updating Failed");
				returnObjList.add(c);
				return new ResponseEntity<List<Cost>>(returnObjList,HttpStatus.OK);
		}
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "getAllgraphdetails")
	public ResponseEntity<List<Graph>> getAllgraphdetails() {
		CostService costService = (CostService) ContextFactory.getContext().getBean(CostService.class);

		List<Graph> resources = new ArrayList<>();
		try {

			resources = costService.getAllgraphdetails();
			return new ResponseEntity<List<Graph>>(resources,
					HttpStatus.OK);
		} catch (Exception e) {
			Environment environment = ContextFactory.getContext()
					.getEnvironment();

			return new ResponseEntity<List<Graph>>(resources,
					HttpStatus.BAD_REQUEST);
		}
	}
}
