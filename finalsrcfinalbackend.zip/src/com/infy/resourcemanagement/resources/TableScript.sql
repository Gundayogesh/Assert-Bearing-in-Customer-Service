DROP TABLE projectMaster CASCADE CONSTRAINTS;
drop table ProjectResource CASCADE CONSTRAINTS;
drop table costEntity CASCADE CONSTRAINTS;
DROP TABLE resourceMaster CASCADE CONSTRAINTS;
DROP TABLE costEntity CASCADE CONSTRAINTS;


SELECT * FROM projectMaster;
select * from resourceMaster;
select * from ProjectResource
select * from costEntity






--CREATE TABLE projectMaster (
--	projectName VARCHAR(30) PRIMARY KEY ,
--	projectRTN VARCHAR(30) UNIQUE,
--	gwnNumber NUMBER NOT NULL,
--	chargeWorkOrderNo NUMBER NOT NULL,
--	projectStartDate DATE NOT NULL,
--	projectEndDate DATE NOT NULL,
--	workOrderValue NUMBER NOT NULL,
--	workOrderManage VARCHAR(30) NOT NULL
--);
--
--INSERT INTO projectMaster VALUES('InfyTQ1','RTN1',1001,2001,'12-Feb-2002','12-Apr-2002',350000,'Sriram');
--INSERT INTO projectMaster VALUES('InfyTQ2','RTN2',1002,2002,'14-Feb-2003','14-Apr-2003',450000,'Yogesh');
--INSERT INTO projectMaster VALUES('InfyTQ3','RTN3',1003,2003,'16-Feb-2004','15-Apr-2004',550000,'Kohli');
--
--
--CREATE TABLE resourceMaster(
--resourceName VARCHAR(30) NOT NULL,
--empNo NUMBER PRIMARY KEY,
--unit VARCHAR(30) NOT NULL,
--clientManager VARCHAR(30) NOT NULL,
--ntidCreated VARCHAR(30) NOT NULL,
--startDate DATE NOT NULL,
--endDate DATE NOT NULL,
--infyManager VARCHAR(30) NOT NULL
--);
--
--INSERT INTO resourceMaster VALUES('Krishna',5001,'JEE','Madhuri','Kishore','15-Feb-2004','16-Apr-2004','Sriram');
--INSERT INTO resourceMaster VALUES('VenuGopal',5005,'UI','Madhuri','Kishore','15-Feb-2003','16-Apr-2003','Yogesh');
--INSERT INTO resourceMaster VALUES('Praveen',5008,'DataAnalyst','Madhuri','Kishore','15-Feb-2002','16-Apr-2002','Yogesh');
--
--COMMIT;
--