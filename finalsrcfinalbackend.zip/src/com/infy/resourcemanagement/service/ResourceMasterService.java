package com.infy.resourcemanagement.service;

import java.util.List;

import com.infy.resourcemanagement.model.ResourceMaster;

public interface ResourceMasterService {
	public ResourceMaster getResourceMaster(Integer empNo) throws Exception;

	public Integer addResourceMaster(ResourceMaster resource) throws Exception;

	public void updateResourceMaster(ResourceMaster resource) throws Exception;

	public void deleteResourceMaster(Integer empNo) throws Exception;

	List<ResourceMaster> getallResources() throws Exception;

	
	List<ResourceMaster> getResourceByVisaManager(String visaManager)
			throws Exception;

	List<ResourceMaster> getResourceByProjectCode(String projectCode)
			throws Exception;


}

