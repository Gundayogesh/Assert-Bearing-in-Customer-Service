package com.infy.resourcemanagement.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.resourcemanagement.dao.ResourceMasterDAO;
import com.infy.resourcemanagement.model.ResourceMaster;

@Service(value = "resourceMasterService")
@Transactional(readOnly = true)
public class ResourceMasterserviceImpl implements ResourceMasterService {
	@Autowired
	private ResourceMasterDAO resourceMasterDAO;
	
//	@Autowired
//	private ResourceRepository resourceRepository;
	
	@Override
	public ResourceMaster getResourceMaster(Integer empNo) throws Exception {
		// TODO Auto-generated method stub
		ResourceMaster resourceMaster=null;
		resourceMaster=resourceMasterDAO.getResourceMaster(empNo);
		return resourceMaster;
	}
	
	@Override
	public List<ResourceMaster> getallResources() throws Exception{
		
		List<ResourceMaster> resources=new ArrayList<>();
		resources=resourceMasterDAO.getAllResources();
		return resources;
		
	}
	
	@Override
	public List<ResourceMaster> getResourceByProjectCode(String projectCode) throws Exception{
		
		List<ResourceMaster> resources=new ArrayList<>();
		resources=resourceMasterDAO.getResourceByProjectCode(projectCode);
		return resources;
		
	}
	
	@Override
	public List<ResourceMaster> getResourceByVisaManager(String visaManager) throws Exception{
		
		List<ResourceMaster> resources=new ArrayList<>();
		resources=resourceMasterDAO.getResourceByVisaManager(visaManager);
		return resources;
		
	}
	

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer addResourceMaster(ResourceMaster resource) throws Exception {
		// TODO Auto-generated method stub
//		ResourceMaster rm=resourceRepository.save(resource);
		System.out.println("2");
		return resourceMasterDAO.addResourceMaster(resource);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void updateResourceMaster(ResourceMaster resource) throws Exception {
		// TODO Auto-generated method stub
		if(resourceMasterDAO.getResourceMaster(resource.getEmpNo())!=null){
			resourceMasterDAO.updateResourceMaster(resource);
		}
		else
		{
			throw new Exception("Service.RESOURCE_MASTER_NOT_FOUND");
		}
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void deleteResourceMaster(Integer empNo) throws Exception {
		// TODO Auto-generated method stub
		if(resourceMasterDAO.getResourceMaster(empNo)!=null){
			resourceMasterDAO.deleteResourceMaster(empNo);
		}
		else
		{
			throw new Exception("Service.RESOURCE_MASTER_NOT_FOUND");
		}
	}

}
