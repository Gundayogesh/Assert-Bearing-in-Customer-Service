package com.infy.resourcemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.resourcemanagement.dao.CostEntityDAO;
import com.infy.resourcemanagement.model.Cost;
import com.infy.resourcemanagement.model.Graph;
import com.infy.resourcemanagement.model.ResourceMaster;



@Service(value = "costService")
@Transactional(readOnly = true)
public class CostService {
	
	@Autowired
	private CostEntityDAO ced;
	
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void addTimesheetForNewResource(ResourceMaster r) throws Exception{
		ced.addTimesheetForNewResource(r);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void addCostEntity(Cost cost) throws Exception {
		// TODO Auto-generated method stub
		ced.addTimesheet(cost);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public double amountTillDateService(Cost cost) throws Exception {
		// TODO Auto-generated method stub
		return  ced.amountTillDate(cost);
	}

	public List<Cost> getALLCostEntity() throws Exception {
		// TODO Auto-generated method stub
		return  ced.getAllCostEntity();
	}

	public List<Graph> getAllgraphdetails() throws Exception {
		// TODO Auto-generated method stub
		return  ced.getAllgraphdetails();
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void updateTimeSheet(List<Cost> costList) throws Exception {
		// TODO Auto-generated method stub
		  ced.updateTimesheet(costList);
	}
}
