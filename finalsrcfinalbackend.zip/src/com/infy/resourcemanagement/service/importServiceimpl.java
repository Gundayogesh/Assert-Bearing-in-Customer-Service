package com.infy.resourcemanagement.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

@Service(value = "importService")

public class importServiceimpl implements importService {
	
	public void import1(FileBean fileBean) {

	    ByteArrayInputStream bis = new ByteArrayInputStream(fileBean.getFileData().getBytes());
		
		Workbook workbook;
	    HSSFSheet sheet = null;
	    try {
	    	//FileInputStream bis = new FileInputStream(new File("D:/Intern_project_sample_date.xlsx"));
	            workbook = new HSSFWorkbook(bis);
	            sheet=(HSSFSheet) workbook.getSheetAt(0);
	      
	            Iterator ite = sheet.rowIterator();
	    		while(ite.hasNext()){
	    			Row row = (Row) ite.next();
	    			Iterator<Cell> cite = row.cellIterator();
	    			while(cite.hasNext()){
	    				Cell c = cite.next();
	    				System.out.print(c.toString() +"  ");
	    			}
	    			System.out.println();
	    		}
	        

	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

}
