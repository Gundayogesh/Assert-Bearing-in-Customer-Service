package com.infy.resourcemanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.resourcemanagement.dao.LoginDAO;
import com.infy.resourcemanagement.model.Login;



@Service(value = "loginservice")
@Transactional(readOnly = true)
public class Loginservice {
	
	@Autowired
	private LoginDAO ld;
	public Login getUser(String userName) throws Exception {
		
		Login login=null;
		login=ld.getuser(userName);
		return login;
	}

 
 @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String addUser(Login user) throws Exception {
		// TODO Auto-generated method stub
		return  ld.addUser(user);
	}

}
