package com.infy.resourcemanagement.service;

import java.util.List;

import com.infy.resourcemanagement.model.ProjectMaster;;

public interface ProjectMasterService {
	public ProjectMaster getProjectMaster(String projectName) throws Exception;

	public String addProjectMaster(ProjectMaster project) throws Exception;

	public void updateProjectMaster(ProjectMaster project) throws Exception;

	public void deleteProjectMaster(String projectName) throws Exception;

	

	public List<ProjectMaster> getAllProjects() throws Exception;



}
