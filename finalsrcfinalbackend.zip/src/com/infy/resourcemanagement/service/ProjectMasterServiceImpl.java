package com.infy.resourcemanagement.service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.resourcemanagement.dao.ProjectMasterDAO;
import com.infy.resourcemanagement.model.ProjectMaster;
import com.infy.resourcemanagement.model.ResourceMaster;


@Service(value = "projectMasterService")
@Transactional(readOnly = true)
public class ProjectMasterServiceImpl implements ProjectMasterService{

	@Autowired
	private ProjectMasterDAO projectMasterDAO;
	
	@Override
	public ProjectMaster getProjectMaster(String projectName) throws Exception {
		
		ProjectMaster projectmaster=null;
		projectmaster=projectMasterDAO.getProjectMaster(projectName);
		return projectmaster;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String addProjectMaster(ProjectMaster project) throws Exception {
		// TODO Auto-generated method stub
		return  projectMasterDAO.addProjectMaster(project);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void updateProjectMaster(ProjectMaster project) throws Exception {
		// TODO Auto-generated method stub
		
		

			if (projectMasterDAO.getProjectMaster(project.getWOName())!= null) {
				projectMasterDAO.updateProjectMaster(project);
			} else {
				throw new Exception("Service.PROJECT_MASTER_NOT_FOUND");
			}

		
		
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void deleteProjectMaster(String projectName) throws Exception {
		// TODO Auto-generated method stub
		if (projectMasterDAO.getProjectMaster(projectName) != null)
			projectMasterDAO.deleteProjectMaster(projectName);
		else
			throw new Exception("Service.PROJECT_MASTER_NOT_FOUND");
	}
	
	@Override
	public List<ProjectMaster> getAllProjects() throws Exception{
		
		List<ProjectMaster> projects=new ArrayList<>();
		projects=projectMasterDAO.getAllProjects();
		return projects;
		
	}
		
	

}
