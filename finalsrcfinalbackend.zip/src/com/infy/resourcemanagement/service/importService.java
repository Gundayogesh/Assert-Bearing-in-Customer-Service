package com.infy.resourcemanagement.service;
import  com.infy.resourcemanagement.service.FileBean;;


	public interface importService {
		
		 public static void import1(FileBean fileBean) {
			// TODO Auto-generated method stub
			
		}

	   
	}


