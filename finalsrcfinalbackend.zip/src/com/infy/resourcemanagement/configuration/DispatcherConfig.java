package com.infy.resourcemanagement.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@EnableWebMvc
@ComponentScan(basePackages = "com.infy.resourcemanagement.api com.infy.resourcemanagement.readDatafromExcel")
public class DispatcherConfig
{

}
