package com.infy.resourcemanagement.entity;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="resourceMaster")
public class ResourceMasterEntity {
	@Id
	private Integer empNo;

	private Integer visaNumber;
	private String resourceName;
	
	private String unit;
	private String LOC;
	private String city;
	private String primarySkill;
	private String secondarySkill;
	private String visaManager;
	private String infyManager;
	private String projectCode;
	private Double rate;
	private String role;
	private String jobTier;
	public Double getRate() {
		return rate;
	}
	public void setRate(Double rate) {
		this.rate = rate;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public Integer getEmpNo() {
		return empNo;
	}
	public void setEmpNo(Integer empNo) {
		this.empNo = empNo;
	}
	public Integer getVisaNumber() {
		return visaNumber;
	}
	public void setVisaNumber(Integer visaNumber) {
		this.visaNumber = visaNumber;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getLOC() {
		return LOC;
	}
	public void setLOC(String lOC) {
		LOC = lOC;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPrimarySkill() {
		return primarySkill;
	}
	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}
	public String getSecondarySkill() {
		return secondarySkill;
	}
	public void setSecondarySkill(String secondarySkill) {
		this.secondarySkill = secondarySkill;
	}
	public String getVisaManager() {
		return visaManager;
	}
	public void setVisaManager(String visaManager) {
		this.visaManager = visaManager;
	}
	public String getInfyManager() {
		return infyManager;
	}
	public void setInfyManager(String infyManager) {
		this.infyManager = infyManager;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getJobTier() {
		return jobTier;
	}
	public void setJobTier(String jobTier) {
		this.jobTier = jobTier;
	}
	
}
