package com.infy.resourcemanagement.entity;

import java.io.Serializable;




public class CompositePrimaryKey implements Serializable{

	private String month ;
	private Integer empNo;
	
	
	
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public Integer getEmpNo() {
		return empNo;
	}
	public void setEmpNo(Integer empNo) {
		this.empNo = empNo;
	}
	
}
