package com.infy.resourcemanagement.entity;

public class GraphEntity {

	
	
}
